//
//  ShowView.m
//  TianQi
//
//  Created by LM on 17/3/29.
//  Copyright © 2017年 LM. All rights reserved.
//

#import "ShowView.h"

#import "ThemeLabel.h"

#import "weatherData.h"
#import "ActiveData.h"

#import "UIImageView+WebCache.h"

#import <AVFoundation/AVFoundation.h>

@interface ShowView () {
    
    __weak IBOutlet ThemeLabel *weatherNum;
    
    __weak IBOutlet UIView *jView;
    __weak IBOutlet UILabel *jDay;
    __weak IBOutlet UILabel *jTemperature;
    __weak IBOutlet UIImageView *jdayPictureImgView;
    __weak IBOutlet UIImageView *jnightPictureImgView;
    __weak IBOutlet UILabel *jPM25;
    __weak IBOutlet UILabel *jWeather;
    
    
    __weak IBOutlet UIView *mView;
    __weak IBOutlet UILabel *mDay;
    __weak IBOutlet UILabel *mTemperature;
    __weak IBOutlet UIImageView *mdayPictureImgView;
    __weak IBOutlet UIImageView *mnightPictureImgView;
    __weak IBOutlet UILabel *mPM25;
    __weak IBOutlet UILabel *mWeather;
    
    __weak IBOutlet UIButton *speakButton;
    
    //合成器的说话内容 可以控制说话的语速 等
    AVSpeechUtterance *utterance;
    // 合成器 控制播放，暂停
    AVSpeechSynthesizer *synth;
    // 实例化说话的语言，说中文、英文
    AVSpeechSynthesisVoice *voice;
}

@end

@implementation ShowView

- (void)setDataDic:(NSMutableDictionary *)dataDic {
    _dataDic = dataDic;
    
    //NSLog(@"%@",self.dataDic);
    WeatherData *jdayData = _dataDic[@"weatherDataArr"][0];
    
    jDay.text = @"今天";
    jTemperature.text = jdayData.temperature;
    jWeather.text = jdayData.weather;
    jPM25.text = jdayData.wind;
    [jdayPictureImgView sd_setImageWithURL:[NSURL URLWithString:jdayData.dayPictureUrl]];
    [jnightPictureImgView sd_setImageWithURL:[NSURL URLWithString:jdayData.nightPictureUrl]];
    
    
    weatherNum.text = [self setFormateWithText:jdayData.date][@"realTempture"];
    
    
    WeatherData *mdayData = _dataDic[@"weatherDataArr"][1];
    
    mDay.text = @"明天";
    mTemperature.text = mdayData.temperature;
    mWeather.text = mdayData.weather;
    mPM25.text = mdayData.wind;
    [mdayPictureImgView sd_setImageWithURL:[NSURL URLWithString:mdayData.dayPictureUrl]];
    [mnightPictureImgView sd_setImageWithURL:[NSURL URLWithString:mdayData.nightPictureUrl]];
}

- (void)awakeFromNib {
    
    self.backgroundColor = self.bgColor;
    
    jView.backgroundColor = [UIColor colorWithWhite:20/255.0 alpha:0.2];
    jView.layer.cornerRadius = 8;
    
    mView.backgroundColor = [UIColor colorWithWhite:20/255.0 alpha:0.2];
    mView.layer.cornerRadius = 8;
    
    [speakButton addTarget:self action:@selector(speakButtonAction:) forControlEvents:UIControlEventTouchUpInside];

}

//"周四 03月23日 (实时：25℃)"

/*
 //7. like    *:任意多个字符    ? : 表示任意单个字符
 
 name like *a    以a结尾
 name like *a*   字符中包含a的字符
 name like ?a*   第二个字符为a的字符串
 
//        s = [NSString stringWithFormat:@"name like '?a*' && age>40"];
s = [NSString stringWithFormat:@"name like [c] '?a*'"];   //[c] 不区分大小写
 */
- (NSDictionary *) setFormateWithText:(NSString *) strText {
    
    NSArray *strArr = [strText componentsSeparatedByString:@" "] ;
    
    //NSString *realTempture = [[strArr[2] componentsSeparatedByString:@"0123456789"] componentsJoinedByString:@""];
    
    NSString *realTempture = [[strArr[2] componentsSeparatedByCharactersInSet:[[NSCharacterSet characterSetWithCharactersInString:@"0123456789"] invertedSet]] componentsJoinedByString:@""];
    
    NSDictionary *dic = @{
                          @"week":strArr[0],
                          @"monthDay":strArr[1],
                          @"realTempture":[NSString stringWithFormat:@"%@℃",realTempture]
                          };
    
    //NSString *strippedBbox = [strText stringByReplacingOccurrencesOfString:@"[^0-9]" withString:@"" options:NSRegularExpressionSearch range:NSMakeRange(0, [strText length])];
    
    //NSLog(@"正则：%@",strippedBbox);
    return dic;
}

- (void)speakButtonAction:(UIButton *)btn {
    
    btn.selected = !btn.selected;
    
    if (btn.selected) {
        
        [self createSpeak];

    } else {
        
        [synth stopSpeakingAtBoundary:AVSpeechBoundaryImmediate];
        utterance = nil;
        synth = nil;
        voice = nil;
    }
}

- (void) createSpeak {
    
    NSString *m_strLang = @"zh-Hans";
    
    //NSString *warnmsg = @"";
    NSString *warnmsg = [self getSpeakContent];
    
    if( [[[UIDevice currentDevice] systemVersion] integerValue] >= 7.0)
    {
        //实例化发声对象 AVSpeechUtterance，指定要朗读的内容
        // 朗诵文本框中的内容
        // 实例化发声的对象，及朗读的内容
        //合成器的说话内容 可以控制说话的语速 等
        utterance = [AVSpeechUtterance speechUtteranceWithString:warnmsg];
        utterance.rate *= 0.8;
        
        // 合成器 控制播放，暂停
        synth = [[AVSpeechSynthesizer alloc] init];
        //获取当前系统语音
        NSString *preferredLang = @"";
        if ([m_strLang isEqualToString:@"zh-Hans"])
        {
            preferredLang = @"zh-CN";
        }else{
            preferredLang = @"en-US";
        }
        
        // 实例化说话的语言，说中文、英文
        voice = [AVSpeechSynthesisVoice voiceWithLanguage:[NSString stringWithFormat:@"%@",preferredLang]];
        utterance.voice = voice;
        [synth speakUtterance:utterance];
    }
    
}

//语音播报内容
- (NSString *) getSpeakContent {
    
    //设置分享内容
    WeatherData *weatherData = _dataDic[@"weatherDataArr"][0];
    
    NSString *text = [NSString string];
    
    for (ActiveData *activeData in _dataDic[@"activeDataArr"]) {
        
        text = [text stringByAppendingString:activeData.des];
    }
    
    NSString *content = [NSString stringWithFormat:@"今日天气%@,气温在%@之间,%@",weatherData.weather,weatherData.temperature,text];
    
    return content;
    
}

@end
