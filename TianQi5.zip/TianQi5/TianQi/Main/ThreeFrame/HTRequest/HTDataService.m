//
//  WCDataService.m
//  03 DataService
//
//  Created by bing on 16/8/13.
//  Copyright © 2016年 bing. All rights reserved.
//

#import "HTDataService.h"
#define boundary @"ffffffff"

#define BaseURL @"https://api.weibo.com/2/"

@implementation HTDataService

+(void)getWithURL:(NSString*)urlStr
           params:(NSMutableDictionary*)params
      headerField:(NSMutableDictionary*)headerFields
  comPletionBlock:(CompletionBlock)block{

    //使用NSUrlSession
    
    //1 url
    NSString *urlString = urlStr;
    //添加一个公共的请求头
    //    [request setValue:@"gzip" forHTTPHeaderField:@"Accept-Encoding"];
    
        
        //@{key1:value1,key2:value2}
        //装换成字符串
        //key1=value1&key2=value2
    
    if (params == nil) {
        
        params = [NSMutableDictionary dictionary];
    }
    
    
        NSMutableString *paramStr = [NSMutableString string];
        
        for (NSString *key in params) {
            
            id value = [params objectForKey:key];
            
            NSString *keyValue = [NSString stringWithFormat:@"%@=%@&",key,value];
            
            [paramStr appendFormat:@"%@",keyValue];
            
        }
        //循环完后 paramStr:  key1=value1&key2=value2&
    
    if (paramStr.length>0) {
        //删除字符串最后一个字符  key1=value1&key2=value2
        [paramStr deleteCharactersInRange:NSMakeRange(paramStr.length-1, 1)];
    }
    
    
        
    NSString *fullUrlStr = [urlString stringByAppendingFormat:@"?%@",paramStr];
    
    NSURL *url = [NSURL URLWithString:fullUrlStr];
    
    //2 request 请求( 请求体)
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:120];
    //请求方式
    [request setHTTPMethod:@"GET"];
    //请求头
    [request setAllHTTPHeaderFields:headerFields];
    
    
    //3 session
    NSURLSession *session = [NSURLSession sharedSession];
    
    //4 task
    NSURLSessionDataTask *task = [session dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        
        if (error != nil) {
            
            NSLog(@"error = %@",error);
            
            return;
        }
        
        NSHTTPURLResponse *httpRes = (NSHTTPURLResponse*)response;
        
        if (httpRes.statusCode == 200) {
            
            id jsonData = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
            
            //block的回调
            //作用:将新的数据显示在界面上,要回调主线程
            dispatch_async(dispatch_get_main_queue(), ^{
                
                block(jsonData);
            });
            
        }else{
            
            NSLog(@"%ld",httpRes.statusCode);
            
        }
        
    }];
    
    //5 resume
    [task resume];
    
    
    
}

+(void)postWithURL:(NSString*)urlStr
            params:(NSMutableDictionary*)params
       headerField:(NSMutableDictionary*)headerFields
          formData:(NSData*)formData
   comPletionBlock:(CompletionBlock)block{
    
    //使用NSUrlSession
    
    //1 url
    NSString *urlString = [BaseURL stringByAppendingString:urlStr];
    NSURL *url = [NSURL URLWithString:urlString];
    
    //2 request 请求( 请求体)
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:120];
    //请求方式
    [request setHTTPMethod:@"POST"];
    //请求头
    [request setAllHTTPHeaderFields:headerFields];
    
    //添加一个公共的请求头
//    [request setValue:@"gzip" forHTTPHeaderField:@"Accept-Encoding"];
    
    //重点:请求体
    if (formData ==nil) {
        
        //发微博文字 (简单数据)
        
        //@{key1:value1,key2:value2}
        //装换成字符串
        //key1=value1&key2=value2
        
        NSMutableString *paramStr = [NSMutableString string];
        
        
        for (NSString *key in params) {
            
            id value = [params objectForKey:key];
            
            NSString *keyValue = [NSString stringWithFormat:@"%@=%@&",key,value];
            
            [paramStr appendFormat:@"%@",keyValue];
            
        }
        //循环完后 paramStr:  key1=value1&key2=value2&
        
        //删除字符串最后一个字符
        [paramStr deleteCharactersInRange:NSMakeRange(paramStr.length-1, 1)];
        
        //字符串---->NSData
        NSData *bodyData = [paramStr dataUsingEncoding:NSUTF8StringEncoding];
        
        [request setHTTPBody:bodyData];
        
    }else{
    
        //发微博+图片 (有复杂数据)
        
        //(2)请求头
        //上传任务,必须要添加的字段
        NSString *contentType = [NSString stringWithFormat:@"multipart/form-data; charset=utf-8;boundary=%@",boundary];
        
        [request setValue:contentType forHTTPHeaderField:@"Content-Type"];
        
        //(3)请求体
        //[1] 文字(参数)  [2]data:(formData)
        NSData *bodydata = [self buildBodyDataWithParams:params formData:formData];
        
        [request setHTTPBody:bodydata];
        
    }
    
    //3 session
    NSURLSession *session = [NSURLSession sharedSession];
    
    //4 task
    NSURLSessionDataTask *task = [session dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
       
        if (error != nil) {
            
            NSLog(@"error = %@",error);
            
            return;
        }
        
        NSHTTPURLResponse *httpRes = (NSHTTPURLResponse*)response;
        
        if (httpRes.statusCode == 200) {
            
            id jsonData = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
            
            //block的回调
            //作用:将新的数据显示在界面上,要回调主线程
            dispatch_async(dispatch_get_main_queue(), ^{
            
                block(jsonData);
            });
            
        }else{
        
            NSLog(@"%ld",httpRes.statusCode);
            
        }
        
    }];
    
    //5 resume
    [task resume];
    
}

+(NSData*)buildBodyDataWithParams:(NSMutableDictionary*)params formData:(NSData*)formData{

    //(1)bodyStr
    
    NSMutableString *bodyStr = [NSMutableString string];
    for (NSString *key in params) {
        
        id value = [params objectForKey:key];
        
        [bodyStr appendFormat:@"--%@\r\n",boundary];//\n:换行 \n:切换到行首
        [bodyStr appendFormat:@"Content-Disposition: form-data; name=\"%@\"",key];
        [bodyStr appendFormat:@"\r\n\r\n"];
        [bodyStr appendFormat:@"%@\r\n",value];
        
    }
    
    //3 pic
    /*
     --AaB03x
     Content-disposition: form-data; name="pic"; filename="file"
     Content-Type: application/octet-stream
     */
    [bodyStr appendFormat:@"--%@\r\n",boundary];
    [bodyStr appendFormat:@"Content-disposition: form-data; name=\"pic\"; filename=\"file\""];
    [bodyStr appendFormat:@"\r\n"];
    [bodyStr appendFormat:@"Content-Type: application/octet-stream"];
    [bodyStr appendFormat:@"\r\n\r\n"];

    
    NSMutableData *bodyData = [NSMutableData data];
    
    //(1)startData
    NSData *startData = [bodyStr dataUsingEncoding:NSUTF8StringEncoding];
    [bodyData appendData:startData];
    
    //(2)pic
    [bodyData appendData:formData];
    
    //(3)--Str--
    NSString *endStr = [NSString stringWithFormat:@"\r\n--%@--\r\n",boundary];
    NSData *endData = [endStr dataUsingEncoding:NSUTF8StringEncoding];
    [bodyData appendData:endData];
    
    return bodyData;
    
}


@end
