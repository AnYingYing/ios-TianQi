//
//  WeatherView.m
//  TianQi
//
//  Created by LM on 17/3/23.
//  Copyright © 2017年 LM. All rights reserved.
//

#import "WeatherView.h"

#import "ThemeImgView.h"
#import "ThemeLabel.h"

#import "ShowView.h"

#import "weatherData.h"

#import "weatherOneCollectionCell.h"
#import "weatherTwoCollectionCell.h"

@interface WeatherView () <UICollectionViewDataSource,UICollectionViewDelegate> {
    
    ShowView *showV;
    
    ThemeImgView *bgImgView;
    
    UICollectionView *_collectionView;
}

@end

@implementation WeatherView


- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        [self createBgImgView];
        [self createScrollView];
        [self setupCollectionView];
        
    }
    return self;
}

- (void)setDataDic:(NSMutableDictionary *)dataDic {
    _dataDic = dataDic;
    
    //传递数据
    showV.dataDic = dataDic;
    //NSLog(@"%@",self.dataDic);
    
    
    WeatherData *data = _dataDic[@"weatherDataArr"][0] ;
    
    NSString *picName = [[data.dayPictureUrl lastPathComponent] stringByReplacingOccurrencesOfString:@"png" withString:@"jpg"];
    //[picName stringByReplacingOccurrencesOfString:@"png" withString:@"jpg"];
    
    //NSLog(@"%@",picName);
    
    //设置背景图片名
    bgImgView.imgName = picName;
    
    [_collectionView reloadData];
    
}

/*!
 创建滑动视图
 */
- (void) createScrollView {
    
    
    _scroll = [[UIScrollView alloc] initWithFrame:self.bounds];
    
    //取消反弹,将取消反弹关闭才能使用明杰刷新
    //_scroll.bounces = NO;
    
    _scroll.contentSize = CGSizeMake(kwidth,(self.bounds.size.height-49-25)*2 );
    
    _scroll.showsVerticalScrollIndicator = NO;
    _scroll.showsHorizontalScrollIndicator = NO;
    
    [self addSubview:_scroll];
    
    
    
    //从Nib上加载视图
    showV = [[[NSBundle mainBundle] loadNibNamed:@"show" owner:self options:nil] objectAtIndex:0];
    
    showV.frame = CGRectMake(0, kheight-65-50-260, kwidth, kheight);
    
    showV.bgColor = [UIColor colorWithRed:115.0/255 green:118.0/255 blue:118.0/255 alpha:0.08];
    
    
    
    [_scroll addSubview:showV];
    
}

/*!
 创建背景主题
 */
- (void) createBgImgView {
    
    //UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 0, 0)];
    
    bgImgView = [[ThemeImgView alloc] initWithFrame:self.bounds];
    
    
    
    //imgView.backgroundColor = [UIColor redColor];
    
    //imgView.imgName = @"bg_snow.jpg";
    
    //[scroll addSubview:view];
    [self addSubview:bgImgView];
    
    
}


//创建集合视图
-(void)setupCollectionView {
    //集合视图
    UICollectionViewFlowLayout *flowLayout = [[UICollectionViewFlowLayout alloc] init];
    flowLayout.scrollDirection = UICollectionViewScrollDirectionVertical;
    flowLayout.headerReferenceSize = CGSizeMake([UIScreen mainScreen].bounds.size.width, 15);//每组头部
    _collectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(0,620, kwidth, 600) collectionViewLayout:flowLayout];
    
    _collectionView.backgroundColor = [UIColor clearColor];
    _collectionView.alpha = 0.98;
    [self.scroll addSubview:_collectionView];
    _collectionView.dataSource = self;
    _collectionView.delegate = self;
    
    _collectionView.scrollEnabled = NO;
    
    [_collectionView registerNib:[UINib nibWithNibName:@"weatherOneCollectionCell" bundle:nil] forCellWithReuseIdentifier:@"CellOne"];
    
    [_collectionView registerNib:[UINib nibWithNibName:@"weatherTwoCollectionCell" bundle:nil] forCellWithReuseIdentifier:@"CellTwo"];
    
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    
    NSArray *weatherDataArr = _dataDic[@"weatherDataArr"];
    NSArray *activeDataArr = _dataDic[@"activeDataArr"];
    
    if (section==0) {
        return weatherDataArr.count;
    } else {
        
        return activeDataArr.count;
    }
    
    
}

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    
    return 2;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    if (indexPath.section==0) {
        weatherOneCollectionCell *cellOne = [collectionView dequeueReusableCellWithReuseIdentifier:@"CellOne" forIndexPath:indexPath];
        
        cellOne.weatherData = _dataDic[@"weatherDataArr"][indexPath.row];
      
        return cellOne;
    } else {
        
        weatherTwoCollectionCell *cellTwo = [collectionView dequeueReusableCellWithReuseIdentifier:@"CellTwo" forIndexPath:indexPath];
        
        cellTwo.activeData = _dataDic[@"activeDataArr"][indexPath.row];
        
        return cellTwo;
    }
}

-(CGSize)collectionView:(UICollectionView *)collectionView layout:(nonnull UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(nonnull NSIndexPath *)indexPath {
    
    if (indexPath.section==0) {
        return CGSizeMake(kwidth-10, 50);
    } else {
        
        return CGSizeMake(kwidth/2-10, 60);
    }
    
}

-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(5, 5, 5, 5);
}

@end
