//
//  LiveTableViewCell.m
//  TianQi
//
//  Created by LM on 17/3/31.
//  Copyright © 2017年 LM. All rights reserved.
//

#import "LiveTableViewCell.h"

#import "ThemeLabel.h"
#import "ThemeManager.h"

#import "UIImageView+WebCache.h"

@interface LiveTableViewCell () {
    
    __weak IBOutlet UIImageView *pic_imageView;
    
    __weak IBOutlet UILabel *pic_time;
    
    __weak IBOutlet UILabel *pic_place;
}

@end

@implementation LiveTableViewCell

- (void)setModel:(LiveModel *)model {
    
    _model = model;
    
    [pic_imageView sd_setImageWithURL:[NSURL URLWithString:model.original_pic_url]];
    
    //[pic_imageView.image stretchableImageWithLeftCapWidth:pic_imageView.image .size.width/2 topCapHeight:pic_imageView.image .size.height/2];
    
    pic_time.text = model.pic_created_time;
    pic_place.text = model.place;
}

- (void)awakeFromNib {
    
    pic_imageView.layer.cornerRadius = 20;
    pic_imageView.layer.masksToBounds = YES;
    
    //1.根据主题设置背景颜色
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(loadBgColor) name:@"ThemeChange" object:nil];
    
}

- (void) loadBgColor {
    
    //ThemeManager *manager = [ThemeManager shareManager];
    
    //self.backgroundColor = [manage.themeColor ];
    
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"ThemeChange" object:nil];
}


@end
