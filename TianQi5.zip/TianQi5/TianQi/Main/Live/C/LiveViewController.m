//
//  LiveViewController.m
//  MiTao
//
//  Created by LM on 17/3/20.
//  Copyright © 2017年 LM. All rights reserved.
//

#import "LiveViewController.h"

#import "LiveModel.h"

#import "LiveTableViewCell.h"

#import "PictureViewController.h"

#import "DataSource.h"
#import "MJRefresh.h"

@interface LiveViewController () <UITableViewDelegate,UITableViewDataSource> {
    
    UITableView *liveTableView;
    
}

//景点数据数组
@property (nonatomic,strong) NSMutableArray *liveDataArr;

//调用下拉刷新需要改变的本地数据URL
@property (nonatomic,copy) NSString *jsonUrl;

//是否加载完成，防止网络卡时连续刷新数据
@property (nonatomic,assign) BOOL isLoad;

@end

static NSString *cellID = @"reuseCell";

@implementation LiveViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //设置请求数据的URL参数
    self.pageNum = 5;
    self.picSum = 10;
    
    self.isLoad = YES;
    
    //创建表视图
    [self createTableView];
    
    //加载数据
    [self loadData];
    
    //创建下拉刷新
    [self createReload];
    
    //创建上拉加载
    [self createShangReload];
}

- (void)setTitleName:(NSString *)titleName {
    _titleName = titleName;
    
    self.title = titleName;
    
}
- (NSString *)cityLocation {
    
    if (!_cityLocation) {
        _cityLocation = @"43-48-32-38-30-31-30-31";
    }
    return _cityLocation;
}

/*!
 创建表视图
 */
- (void) createTableView {
    
    liveTableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
    
    liveTableView.dataSource = self;
    liveTableView.delegate = self;
    liveTableView.rowHeight = 300;
    
    //注册cell
    [liveTableView registerNib:[UINib nibWithNibName:@"LiveTableViewCell" bundle:nil] forCellReuseIdentifier:cellID];
    
    
    [self.view addSubview:liveTableView];
}

/*!
 创建下拉刷新
 */
- (void) createReload {
    
    liveTableView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        
        self.pageNum --;
        
        [self loadData];
        
    }];
    
}

- (void) createShangReload {
    
    liveTableView.footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
        
        self.pageNum ++;
        
        [self loadOldData];
        
    }];
    
}

/*!
 请求网络数据
 */
 - (void) loadData {
     
     //http://open.weather.sina.com.cn/api/img/getFeeds/43-48-32-38-30-31-30-31/2/20
     NSString *urlStr = [NSString stringWithFormat:@"http://open.weather.sina.com.cn/api/img/getFeeds/%@/%ld/%ld",self.cityLocation,self.pageNum,self.picSum];
     
     //防止上一条数据未加载完成连续调用加载数据
     if (self.isLoad) {
         
         self.isLoad = NO;
         //头部刷新控件开始刷新
         [liveTableView.header beginRefreshing];
         
         [DataSource requestURL:urlStr requestHeadDic:nil method:@"get" params:nil fileData:nil success:^(id responseResult) {
             
             NSArray *dataArray = [responseResult[@"result"][@"data"] objectForKey:self.cityLocation];
             
             //封装请求到的数据
             [self packageData:dataArray];
             
             self.isLoad = YES;
             //头部刷新控件结束刷新
             [liveTableView.header endRefreshing];
             
         } faile:^(NSError *error) {
             
             NSLog(@"请求最新数据失败");
         }];

     }
 }

//上啦加载，加载老旧数据
- (void) loadOldData {
    NSString *urlStr = [NSString stringWithFormat:@"http://open.weather.sina.com.cn/api/img/getFeeds/%@/%ld/%ld",self.cityLocation,self.pageNum,self.picSum];
    
    //防止上一条数据未加载完成连续调用加载数据
    if (self.isLoad) {
        
        self.isLoad = NO;
        //头部刷新控件开始刷新
        [liveTableView.footer beginRefreshing];
        
        [DataSource requestURL:urlStr requestHeadDic:nil method:@"get" params:nil fileData:nil success:^(id responseResult) {
            
            NSArray *dataArray = [responseResult[@"result"][@"data"] objectForKey:self.cityLocation];
            
            //封装请求到的数据
            [self packageOldData:dataArray];
            
            self.isLoad = YES;
            //头部刷新控件结束刷新
            [liveTableView.footer endRefreshing];
            
        } faile:^(NSError *error) {
            
            NSLog(@"请求老旧数据失败");
        }];
        
    }
}

/*
 加载本地数据
 

- (NSArray *) loadLiveData {
    
    NSData *liveData = [NSData dataWithContentsOfFile:[[NSBundle mainBundle] pathForResource:self.jsonUrl ofType:nil]];
    
    NSDictionary *dataDic = [NSJSONSerialization JSONObjectWithData:liveData options:NSJSONReadingMutableContainers error:nil];
    
    NSArray *dataArray = dataDic[@"result"][@"data"][@"43-48-32-38-30-31-30-31"];
    
    return dataArray;
}
 */

/*!
 封装下拉刷新数据
 */
- (void) packageData:(NSArray *) arr {
    
    NSMutableArray *liveDataArr = [[NSMutableArray alloc] init];
    
    for (NSDictionary *dic in arr) {
        LiveModel *model = [[LiveModel alloc] init];
        [model setValueForPropertyWithDic:dic];
        [liveDataArr addObject:model];
    }
    
    self.liveDataArr = liveDataArr;
    //表视图重新加载
    [liveTableView reloadData];
}

/*!
 封装上啦老旧数据
 */
- (void) packageOldData:(NSArray *) arr {
    
    for (NSDictionary *dic in arr) {
        LiveModel *model = [[LiveModel alloc] init];
        [model setValueForPropertyWithDic:dic];
        
        //在原数据数组后面添加上啦老旧数据数组
        [self.liveDataArr addObject:model];

    }
    
    //表视图重新加载
    [liveTableView reloadData];
}


//---------------------表视图代理方法-----------------------
- (NSInteger) numberOfSectionsInTableView:(UITableView *)tableView {
    
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return self.liveDataArr.count;
}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    LiveTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    
    LiveModel *model = self.liveDataArr[indexPath.row];
    
    cell.model = model;
    
    return cell;
    
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    self.modalTransitionStyle = UIModalTransitionStyleFlipHorizontal;
    
    PictureViewController *picVC = [[PictureViewController alloc] init];
    
    picVC.imagesData = [[NSMutableArray alloc] initWithArray:self.liveDataArr];
    
    picVC.selectedNum = indexPath.row;
    
    [self presentViewController:[[UINavigationController alloc] initWithRootViewController:picVC] animated:YES completion:nil];
    
}

@end
