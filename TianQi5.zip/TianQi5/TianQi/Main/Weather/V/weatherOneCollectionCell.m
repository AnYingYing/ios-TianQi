//
//  weatherOneCollectionCell.m
//  TianQi
//
//  Created by LM on 17/4/5.
//  Copyright © 2017年 LM. All rights reserved.
//

#import "weatherOneCollectionCell.h"

#import "UIImageView+WebCache.h"

#import "ThemeLabel.h"

@interface weatherOneCollectionCell () {
    
    __weak IBOutlet ThemeLabel *dayLabel;
    __weak IBOutlet ThemeLabel *p25Label;
    __weak IBOutlet UIImageView *imgView;
    __weak IBOutlet ThemeLabel *weatherLabel;
    __weak IBOutlet ThemeLabel *tempLabel;
}

@end

@implementation weatherOneCollectionCell

- (void)setWeatherData:(WeatherData *)weatherData {
    
    _weatherData = weatherData;
    
    if (weatherData.date.length>2) {
        dayLabel.text = @"今天";
    } else {
        dayLabel.text = weatherData.date;
    }
    
    tempLabel.text = weatherData.temperature;
    weatherLabel.text = weatherData.weather;
    p25Label.text = weatherData.wind;
    [imgView sd_setImageWithURL:[NSURL URLWithString:weatherData.dayPictureUrl]];
    //[mnightPictureImgView sd_setImageWithURL:[NSURL URLWithString:mdayData.nightPictureUrl]];
    
}

- (void)awakeFromNib {
    
    self.backgroundColor = [UIColor colorWithWhite:20/255.0 alpha:0.2];
    self.layer.cornerRadius = 8;
}



@end
