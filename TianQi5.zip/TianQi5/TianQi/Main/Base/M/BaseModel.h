//
//  BaseModel.h
//  WXMovie
//
//  Created by bing on 16/7/22.
//  Copyright © 2016年 bing. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BaseModel : NSObject

-(void)setValueForPropertyWithDic:(NSDictionary*)keyedValues;

@end
