//
//  LiveModel.h
//  TianQi
//
//  Created by LM on 17/3/31.
//  Copyright © 2017年 LM. All rights reserved.
//

#import "BaseModel.h"

/*
 
 {
 "result": {
 "status": {
 "code": 0,
 "msg": "succeeded!"
 },
 "timestamp": "Fri Mar 31 13:17:04 +0800 2017",
 "data": {
 "43-48-32-38-30-31-30-31": [
 {
 "weibo_name": "布丁是我爱的一只虾",
 "screen_name": "布丁是我爱的一只虾",
 "profile_url": "http://weibo.com/u/1757094417",
 "profile_image_url": "http://tva1.sinaimg.cn/crop.0.0.180.180.50/68bb2211jw1e8qgp5bmzyj2050050aa8.jpg",
 "text": "下雨天的圣心大教堂",
 "pic_id": "tqt_4091335562372133",
 "pic_created_time": "2017-03-31 12:17:54",
 "source": "<a href=\"http://app.weibo.com/t/feed/5ui34Y\" rel=\"nofollow\">柔光自拍vivo X7</a>",
 "original_pic_url": "http://wx3.sinaimg.cn/large/68bb2211gy1fe5wi8tzlzj20k00zktc9.jpg",
 "thumbnail_pic_url": "http://s.img.mix.sina.com.cn/auto/resize?img=http%3A%2F%2Fwx3.sinaimg.cn%2Flarge%2F68bb2211gy1fe5wi8tzlzj20k00zktc9.jpg&size=244_0",
 "place": "广州市石室天主堂(南门)",
 "pic_width": "440",
 "pic_height": "782"
 },
 
 */

@interface LiveModel : BaseModel

@property (nonatomic,copy) NSString *weibo_name;
@property (nonatomic,copy) NSString *screen_name;
@property (nonatomic,copy) NSString *profile_url;//微博链接
@property (nonatomic,copy) NSString *profile_image_url;//个人头像
/*! 标题内容 */
@property (nonatomic,copy) NSString *text;//微博标题
@property (nonatomic,copy) NSString *pic_id;//图片id
/*! 发布时间 */
@property (nonatomic,copy) NSString *pic_created_time;//图发布时间
@property (nonatomic,copy) NSString *source;//
/*! 原图 */
@property (nonatomic,copy) NSString *original_pic_url;//原图
/*! 缩略图 */
@property (nonatomic,copy) NSString *thumbnail_pic_url;//缩略图
/*! 图片地点 */
@property (nonatomic,copy) NSString *place;//图片地点
/*! 图片宽（字符串类型） */
@property (nonatomic,copy) NSString *pic_width;//图片宽
/*! 图片高（字符串类型） */
@property (nonatomic,copy) NSString *pic_height;//图片高

@end
