//
//  PictureViewController.m
//  TianQi
//
//  Created by LM on 17/3/31.
//  Copyright © 2017年 LM. All rights reserved.
//

#import "PictureViewController.h"

#import "LiveModel.h"

#import "UIViewExt.h"

#import "ColorMatrix.h"

#import "MoreView.h"

#import <Photos/Photos.h>



#define kScrollViewGap 15

@interface PictureViewController () <MoreViewDelegate>{
    
    MoreView *_moreView;
    //存储所有经过滤镜处理后的图片
    NSArray *effectImages;
}

@end

@implementation PictureViewController


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
    }
    return self;
}



#pragma mark - ViewController Life
- (void)loadView
{
    [super loadView];
    // 创建滑动视图
    [self loadBaseScrollView];
    
    // 自定义导航栏视图
    [self loadNavigationBar];
    
    // 创建标题视图（底部视图）
    [self loadTitleView];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    // 请求"网络"数据
    [self requestData];
    
    
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    if (self.navigationController.viewControllers.count == 2) {
        
        [self.navigationController setNavigationBarHidden:YES animated:YES];
    }
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
}

#pragma mark - Private Method
- (void)loadNavigationBar
{
    _navigationBar = [[UIImageView alloc] initWithFrame:CGRectMake(0, -20, kwidth, 64)];
    _navigationBar.userInteractionEnabled = YES;
    
    //拉伸图片
    UIEdgeInsets insets = UIEdgeInsetsMake(0, 22, 0, 22);
    UIImage *image = [UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"bg_tab_normal@2x.png" ofType:nil]];
    UIImage *img =[image resizableImageWithCapInsets:insets resizingMode:UIImageResizingModeStretch];
    
    _navigationBar.image = img;
    [self.navigationController.navigationBar addSubview:_navigationBar];
    
    UIButton *backButton = [UIButton buttonWithType:UIButtonTypeCustom];
    backButton.frame = CGRectMake(10, 20, 44, 44);
    [backButton setTitle:@"返回" forState:UIControlStateNormal];
    [backButton addTarget:self action:@selector(backRootVC:) forControlEvents:UIControlEventTouchUpInside];
    [_navigationBar addSubview:backButton];
    
    //情景模式按钮
    
    UIButton *moreButton = [UIButton buttonWithType:UIButtonTypeCustom];
    moreButton.frame = CGRectMake(kwidth-44-10, 20, 44, 44);
    [moreButton setTitle:@"情景" forState:UIControlStateNormal];
    [moreButton addTarget:self action:@selector(moreAction) forControlEvents:UIControlEventTouchUpInside];
    [_navigationBar addSubview:moreButton];
    
        
    UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake((kwidth-200)/2, 20, 200, 44)];
    title.text = @"实景图片";
    title.textAlignment = NSTextAlignmentCenter;
    title.textColor = [UIColor whiteColor];
    title.backgroundColor = [UIColor clearColor];
    title.font = [UIFont boldSystemFontOfSize:22];
    [_navigationBar addSubview:title];
    
}

- (void)loadBaseScrollView
{
    _contentScrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, kwidth+kScrollViewGap, kheight)];
    _contentScrollView.pagingEnabled = YES;
    _contentScrollView.delegate = self;
    _contentScrollView.tag = INT_MAX;
    _contentScrollView.showsHorizontalScrollIndicator = NO;
    [self.view addSubview:_contentScrollView];
}

- (void)loadTitleView
{
    _titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, kheight-49, kwidth, 49)];
    _titleLabel.textAlignment = NSTextAlignmentCenter;
    _titleLabel.backgroundColor = [UIColor blackColor];
    _titleLabel.textColor = [UIColor whiteColor];
    _titleLabel.font = [UIFont boldSystemFontOfSize:16];
    _titleLabel.numberOfLines = 0;
    [self.view addSubview:_titleLabel];
}

////////////////////////////////////////////////////////////////////////

- (void)requestData
{
//    NSArray *data = [WXNetworkService newsImageData];
//    
//    _imagesData = [[NSMutableArray alloc] initWithCapacity:data.count];
//    for (id dic in data) {
//        
//        ImageModel *imgModel = [[ImageModel alloc] initWithContent:dic];
//        [_imagesData addObject:imgModel];
//        [imgModel release];
//    }
    
    [self refreshUI];
}

- (void)refreshUI
{
    // 设置滑动视图的内容大小
    _contentScrollView.contentSize = CGSizeMake((kwidth + kScrollViewGap) * _imagesData.count, _contentScrollView.height);
    
    //设置滑动视图根据单元格点击事件显示对应的滑动区域
    _contentScrollView.contentOffset = CGPointMake(self.selectedNum*(kwidth + kScrollViewGap), 64);
    
    
    // 设置进入该控制器时显示的视图标题的内容
    LiveModel *liveModel = _imagesData[self.selectedNum];
    _titleLabel.text = liveModel.place;
    
    int x = 0;
    for (int index = 0; index < _imagesData.count; index++) {
        
        // 取出数据
        LiveModel *imageModel = _imagesData[index];
        
        // 创建视图
        AblumView *ablumView = [[AblumView alloc] initWithFrame:CGRectMake(0+x, 0, kwidth, kheight-20)];
        ablumView.tag = index;
        if (index == self.selectedNum) {
            
            ablumView.url = imageModel.original_pic_url;
            [ablumView downloadImage];
        }
        ablumView.delegate = self;
        [_contentScrollView addSubview:ablumView];
        
        //设置视图的位置
        x += (kwidth + kScrollViewGap);
    }
    
}


////////////////////////////////////////////////////////////////////////

- (void)downloadData:(NSInteger)i
{
    AblumView *_ablumView = (AblumView *)[_contentScrollView viewWithTag:i];
    LiveModel *liveModel = _imagesData[i];
    _ablumView.url = liveModel.original_pic_url;
    [_ablumView downloadImage];
}

#pragma mark - Action Method
- (void)backRootVC:(UIButton *)button
{
    [self dismissViewControllerAnimated:YES completion:nil];
     
}

static BOOL isOpen = YES;
#pragma mark - 情景模式按钮方法
- (void) moreAction{
    
    if (isOpen) {
        isOpen = NO;
        [self createMoreView];
        

    } else {
        
        _moreView.popView.hidden = !_moreView.popView.hidden;
        
        //没有选择任何一项情景模式
        if (_selectedImageIndex==10) {
            isOpen = YES;
            [self addOrRemoveMoreView];
            [self setDefaultImage];

        }
        
    }
}

#pragma mark - 滑动结束，还原上一张视图比例
static int lastIndex = 0;//记录上一张图片索引
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    int index = scrollView.contentOffset.x / (kwidth+kScrollViewGap);
    
    self.selectedNum = index;
    
    if (index >= _imagesData.count || index < 0) {
        return;
    }
    
    // 设置标题
    LiveModel *liveModel = _imagesData[index];
    _titleLabel.text = liveModel.place;
    
    // 还原上一个视图比例
    AblumView *ablumView = (AblumView *)[_contentScrollView viewWithTag:lastIndex];
    if (ablumView.scrollView.zoomScale >= 1 && lastIndex != index) {
        
        ablumView.scrollView.zoomScale = 1;
    }
    
    if (index == 0) {
        // ... noting 2张图片（1， 2）
        for (int i = 0; i <= index+1; i++) {
            // NSLog(@"before : %d", i);
            
        }
        
    }else if (index == _imagesData.count-1) {
        // 2张图片（最后一张和倒数第二章）
        for (int i = index; i >= index-1; i--) {
            //NSLog(@"end :i : %d", i);
            [self downloadData:i];
        }
    }else {
        // 3 4 5
        for (int i = index+1; i >= index-1; i--) {
            //NSLog(@"middle : %d", i);
            [self downloadData:i];
        }
    }
    
    lastIndex = index;
    
    //将图片数组清空
    effectImages = nil;
}

#pragma mark - AblumView Delegate
- (void)hiddenOrShow:(AblumView *)ablumView
{
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.35];
    if (_navigationBar.alpha == 1 && _titleLabel.alpha == 1) {
        _navigationBar.alpha = 0;
        _titleLabel.alpha = 0;
    }else {
        _navigationBar.alpha = 1;
        _titleLabel.alpha = 1;
    }
    [UIView commitAnimations];
}

//-------------------MoreView(更多视图)--------------------------
- (void) createMoreView {
    
    _moreView = [[MoreView alloc] initWithFrame:CGRectMake(0, 0, kwidth, kheight-49)];
    _moreView.delegate = self;
    
    [self.view addSubview:_moreView];
    
}

- (void)addOrRemoveMoreView
{
    if ([_moreView superview]) {
        
        // 先隐藏
        [UIView beginAnimations:nil context:NULL];
        _moreView.alpha = 0;
        [UIView commitAnimations];
        
        // 再移除
        [_moreView performSelector:@selector(removeFromSuperview) withObject:nil afterDelay:0.2];
        
        isOpen = YES;
        
    }
}



static NSInteger _lastIndex = 0;
- (void)changeViewController:(NSInteger)index
{
    if (index >= 4 && _moreView == nil) {
        //创建moreView
        [self createMoreView];
        
    }else {
        //移除moreView
        [self addOrRemoveMoreView];

    }
    
    // 记录上一次选中的状态（tag）
    _lastIndex = (index == 4) ? _lastIndex : index;
}


#pragma mark - 点击背景视图，moreView消失的代理方法
- (void)didMoreViewBackgoundWithTag:(NSInteger)tag
{
    [self changeViewController:tag];
    isOpen = YES;
    
    //点击屏幕默认不修改图片(设置为原始)
    [self setDefaultImage];
    
    //还原索引
    _selectedImageIndex=10;
}

static NSInteger _selectedImageIndex = 10;
#pragma mark - 点击表视图单元格的代理方法
- (void)didSelectTableViewCellIndex:(NSInteger)index
{
    //[self addOrRemoveMoreView];
    _moreView.popView.hidden = YES;
    [self createMoreButton];
        
    AblumView *_ablumView = (AblumView *)[_contentScrollView viewWithTag:self.selectedNum];
    
    NSArray *allImages = [self setEffectImagesWithImage:_ablumView.imgView.image];
    
    _ablumView.imgView.image = allImages[index];
    
    _lastIndex = 4;
    
    _selectedImageIndex = index;
}

//创建MoreView上的取消、保存、收藏按钮
- (void) createMoreButton {
    
    //往moreView上添加按钮
    UIButton *button1 = [UIButton buttonWithType:UIButtonTypeCustom];
    button1.frame = CGRectMake(0, _moreView.bottom-60, 80, 50);
    [button1 setTitle:@"取消" forState:UIControlStateNormal];
    button1.tag = 2000+1;
    [button1 addTarget:self action:@selector(moreBtnAction:) forControlEvents:UIControlEventTouchUpInside];
    [_moreView addSubview:button1];
    
    UIButton *button2 = [UIButton buttonWithType:UIButtonTypeCustom];
    button2.frame = CGRectMake(_moreView.width/2-25, _moreView.bottom-60, 80, 50);
    [button2 setTitle:@"保存" forState:UIControlStateNormal];
    button2.tag = 2000+2;
    [button2 addTarget:self action:@selector(moreBtnAction:) forControlEvents:UIControlEventTouchUpInside];
    [_moreView addSubview:button2];
    
    UIButton *button3 = [UIButton buttonWithType:UIButtonTypeCustom];
    button3.frame = CGRectMake(_moreView.width-60, _moreView.bottom-60, 80, 50);
    [button3 setTitle:@"收藏" forState:UIControlStateNormal];
    button3.tag = 2000+3;
    [button3 addTarget:self action:@selector(moreBtnAction:) forControlEvents:UIControlEventTouchUpInside];
    [_moreView addSubview:button3];
    
}
//设置为原始图片
- (void) setDefaultImage {
    
    AblumView *_ablumView = (AblumView *)[_contentScrollView viewWithTag:self.selectedNum];
    
    if (effectImages[0]) {
        _ablumView.imgView.image = effectImages[0];
    }
    
}

//保存修改的图片
- (void) setChangedImage {
    
    AblumView *_ablumView = (AblumView *)[_contentScrollView viewWithTag:self.selectedNum];
    
    _ablumView.imgView.image = effectImages[_selectedImageIndex];
    
}

- (void) moreBtnAction:(UIButton *)btn{
    //移除moreView
    [self addOrRemoveMoreView];
    
    if (btn.tag==2001) {//取消
        
        [self setDefaultImage];
        
    } else if (btn.tag==2002){//保存
        [self setChangedImage];
        
        //将图片数组清空
        effectImages = nil;
        
    }else if (btn.tag==2003){//收藏到相册
        
        //将图片保存到相册方法一：
        //UIImageWriteToSavedPhotosAlbum(effectImages[_selectedImageIndex], self, @selector(image:didFinishSavingWithError:contextInfo:), nil);
        
        //将图片保存到相册指定相簿方法二：
        [self saveImageInPhoto:effectImages[_selectedImageIndex]];
    }
    //NSLog(@"%ld",btn.tag);
    
    //还原索引
    _selectedImageIndex=10;
}

// 成功保存图片到相册中, 必须调用此方法, 否则会报参数越界错误
- (void)image:(UIImage *)image didFinishSavingWithError:(NSError *)error contextInfo:(void *)contextInfo{
    

}


//--------------------图片渲染---------------------------
- (UIImage*)imageWithImage:(UIImage*)inImage withColorMatrix:(const float*) f
{
    
    unsigned char *pp = [self getPointWithContextData:inImage];
    
    //获取像素指针，作为数据源
    //size_t *pp = [self getPointWithContextData:inImage];
    
    CGImageRef inImageRef = [inImage CGImage];
    int width = CGImageGetWidth(inImageRef);
    int height = CGImageGetHeight(inImageRef);
    
    //图片占多少字节
    int count = width * height;

    uint32_t *p2 = (uint32_t*) pp;
    
    //遍历像素
    for (int i=0; i<count; i++,p2++) {
        
        uint8_t *p = (uint8_t *)p2;
        
        //        int red = (int)p[0];
        //        int green = (int)p[1];
        //        int blue = (int)p[2];
        //        int alpha = (int)p[3];
        
        int red = p[0];
        int green = p[1];
        int blue = p[2];
        int alpha = p[3];
        
        [self changeRGBA:&red :&green :&blue :&alpha :f];
        
        p[0] = red;
        p[1] = green;
        p[2] = blue;
        p[3] = alpha;
        
    }
    
//        int wOff = 0;
//        int pixOff = 0;
//    
//    
//        for(int y = 0;y< height;y++)//双层循环按照长宽的像素个数迭代每个像素点
//        {
//            pixOff = wOff;
//    
//            for (int x = 0; x<width; x++)
//            {
//                int red = (int)pp[pixOff];
//                int green = (int)pp[pixOff+1];
//                int blue = (int)pp[pixOff+2];
//                int alpha = (int)pp[pixOff+3];
//                //changeRGBA(&red, &green, &blue, &alpha, f);
//    
//                [self changeRGBA:&red :&green :&blue :&alpha :f];
//    
//                //回写数据
//                pp[pixOff] = red;
//                pp[pixOff+1] = green;
//                pp[pixOff+2] = blue;
//                pp[pixOff+3] = alpha;
//    
//    
//                pixOff += 4; //将数组的索引指向下四个元素
//            }
//    
//            wOff += width * 4;
//        }
    
    
    //将内存转换成图片，重新定义一个数据源
    CGDataProviderRef dataRef = CGDataProviderCreateWithData(NULL, pp, count*4, nil);
    
    CGColorSpaceRef colorRef = CGColorSpaceCreateDeviceRGB();
    
    //绘制图片
    CGImageRef imgRef = CGImageCreate(width, height, 8, 32, width*4, colorRef, kCGBitmapByteOrderDefault, dataRef, nil, YES, kCGRenderingIntentDefault);
    
    UIImage *image = [UIImage imageWithCGImage:imgRef];
    
    CGColorSpaceRelease(colorRef);
    CGDataProviderRelease(dataRef);
    CGImageRelease(imgRef);
    
    
    return image;
}

//改变像素数组指针所指的值
- (void) changeRGBA:(int*) red :(int*) green :(int*) blue :(int*) alpha :(const float*) f {
    
    int redV = *red;
    int greenV = *green;
    int blueV = *blue;
    int alphaV = *alpha;
    
    *red = f[0] * redV + f[1] * greenV + f[2] * blueV + f[3] * alphaV + f[4];
    *green = f[0+5] * redV + f[1+5] * greenV + f[2+5] * blueV + f[3+5] * alphaV + f[4+5];
    *blue = f[0+5*2] * redV + f[1+5*2] * greenV + f[2+5*2] * blueV + f[3+5*2] * alphaV + f[4+5*2];
    *alpha = f[0+5*3] * redV + f[1+5*3] * greenV + f[2+5*3] * blueV + f[3+5*3] * alphaV + f[4+5*3];
    
    if (*red > 255)
    {
        *red = 255;
    }
    if(*red < 0)
    {
        *red = 0;
    }
    if (*green > 255)
    {
        *green = 255;
    }
    if (*green < 0)
    {
        *green = 0;
    }
    if (*blue > 255)
    {
        *blue = 255;
    }
    if (*blue < 0)
    {
        *blue = 0;
    }
    if (*alpha > 255)
    {
        *alpha = 255;
    }
    if (*alpha < 0)
    {
        *alpha = 0;
    }
    
}

#pragma mark - 根据图片创建一个位图上下文
- (CGContextRef) createBitMapContextWithCGImg:(CGImageRef) imgRef {
    
    CGContextRef context = NULL;
    CGColorSpaceRef colorSpace;
    void *bitmapData; //内存空间的指针，该内存空间的大小等于图像使用RGB通道所占用的字节数。
    int bitmapByteCount;
    int bitmapBytesPerRow;
    
    size_t pixelsWide = CGImageGetWidth(imgRef); //获取横向的像素点的个数
    size_t pixelsHigh = CGImageGetHeight(imgRef); //纵向
    
    bitmapBytesPerRow = (pixelsWide * 4); //每一行的像素点占用的字节数，每个像素点的ARGB四个通道各占8个bit(0-255)的空间
    bitmapByteCount	= (bitmapBytesPerRow * pixelsHigh); //计算整张图占用的字节数
    
    colorSpace = CGColorSpaceCreateDeviceRGB();//创建依赖于设备的RGB通道
    
    bitmapData = malloc(bitmapByteCount); //向系统请求分配足够容纳图片字节数的内存空间
    
    context = CGBitmapContextCreate (bitmapData, pixelsWide, pixelsHigh, 8, bitmapBytesPerRow, colorSpace, kCGImageAlphaPremultipliedLast);
    //创建CoreGraphic的图形上下文，该上下文描述了bitmaData指向的内存空间需要绘制的图像的一些绘制参数
    
    CGColorSpaceRelease( colorSpace );
    //Core Foundation中通过含有Create、Alloc的方法名字创建的指针，需要使用CFRelease()函数释放
    
    return context;
}

#pragma mark - 根据UIImage图片返回一个指向上下文数据来源（像素数组）的指针
- (size_t *) getPointWithContextData:(UIImage *) image {
    
    CGImageRef img = [image CGImage];
    CGSize size = [image size];
    
    //使用上面的函数创建上下文
    CGContextRef cgctx =[self createBitMapContextWithCGImg:img];
    
    CGRect rect = {{0,0},{size.width, size.height}};
    
    //将目标图像绘制到指定的上下文，实际为上下文内的bitmapData。
    CGContextDrawImage(cgctx, rect, img);
    size_t *data = CGBitmapContextGetData (cgctx);
    
    //释放上面的函数创建的上下文
    CGContextRelease(cgctx);
    return data;
    
}

//原始,lomo,黑白,怀旧,哥特,淡雅,酒红,清宁,浪漫,光晕,蓝调,梦幻,夜色
//图片数组懒加载
-(NSArray *)setEffectImagesWithImage:(UIImage *) img {
    if (!effectImages) {
        effectImages = @[img,[self imageWithImage:img withColorMatrix:colormatrix_lomo],[self imageWithImage:img withColorMatrix:colormatrix_heibai],[self imageWithImage:img withColorMatrix:colormatrix_huaijiu],[self imageWithImage:img withColorMatrix:colormatrix_gete],[self imageWithImage:img withColorMatrix:colormatrix_danya],[self imageWithImage:img withColorMatrix:colormatrix_jiuhong],[self imageWithImage:img withColorMatrix:colormatrix_qingning],[self imageWithImage:img withColorMatrix:colormatrix_langman],[self imageWithImage:img withColorMatrix:colormatrix_guangyun],[self imageWithImage:img withColorMatrix:colormatrix_landiao],[self imageWithImage:img withColorMatrix:colormatrix_menghuan],[self imageWithImage:img withColorMatrix:colormatrix_yese]];
    }
    
    return effectImages;
}

//使用PHPhotoLibrary对相册进行操作
//先将要保存的图片保存到相册的“相机胶卷”，然后再添加到新创建的相簿中
- (void)saveImageInPhoto:(UIImage *) image {
    //保存图片
    __block NSString *assetId = nil;
    // 1. 存储图片到"相机胶卷"
    [[PHPhotoLibrary sharedPhotoLibrary] performChanges:^{
        // 新建一个PHAssetCreationRequest对象
        // 返回PHAsset(图片)的字符串标识
        assetId = [PHAssetCreationRequest creationRequestForAssetFromImage:image].placeholderForCreatedAsset.localIdentifier;
    } completionHandler:^(BOOL success, NSError * _Nullable error) {
        // 2. 获得相册对象
        PHAssetCollection *collection = [self getCollection];
        // 3. 将“相机胶卷”中的图片添加到新的相册
        [[PHPhotoLibrary sharedPhotoLibrary] performChanges:^{
            PHAssetCollectionChangeRequest *request = [PHAssetCollectionChangeRequest changeRequestForAssetCollection:collection];
            //NSLog(@"%@", [PHAsset fetchAssetsWithLocalIdentifiers:@[assetId] options:nil]);
            // 根据唯一标示获得相片对象
            PHAsset *asset = [PHAsset fetchAssetsWithLocalIdentifiers:@[assetId] options:nil].firstObject;
            // 添加图片到相册中
            [request addAssets:@[asset]];
        } completionHandler:^(BOOL success, NSError * _Nullable error) {
            NSLog(@"成功保存到相簿：%@", collection.localizedTitle);
            
            
            //保存好后删掉香蕉基卷中的图片
            //[[PHPhotoLibrary sharedPhotoLibrary] delete:assetId];
            
        }];
    }];
}

//创建新的相簿
- (PHAssetCollection *)getCollection {
    // 先获得之前创建过的相册
    PHFetchResult<PHAssetCollection *> *collectionResult = [PHAssetCollection fetchAssetCollectionsWithType:PHAssetCollectionTypeAlbum subtype:PHAssetCollectionSubtypeAlbumRegular options:nil];
    for (PHAssetCollection *collection in collectionResult) {
        if ([collection.localizedTitle isEqualToString:@"我的收藏"]) {
            return collection;
        }
    }
    
    // 如果相册不存在,就创建新的相册(文件夹)
    __block NSString *collectionId = nil; // __block修改block外部的变量的值
    // 这个方法会在相册创建完毕后才会返回
    [[PHPhotoLibrary sharedPhotoLibrary] performChangesAndWait:^{
        // 新建一个PHAssertCollectionChangeRequest对象, 用来创建一个新的相册
        collectionId = [PHAssetCollectionChangeRequest creationRequestForAssetCollectionWithTitle:@"我的收藏"].placeholderForCreatedAssetCollection.localIdentifier;
    } error:nil];
    
    return [PHAssetCollection fetchAssetCollectionsWithLocalIdentifiers:@[collectionId] options:nil].firstObject;
}


@end