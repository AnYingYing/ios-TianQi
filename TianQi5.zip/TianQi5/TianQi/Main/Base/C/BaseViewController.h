//
//  BaseViewController.h
//  MiTao
//
//  Created by LM on 17/3/20.
//  Copyright © 2017年 LM. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseViewController : UIViewController

@end
