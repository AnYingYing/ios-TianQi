//
//  DataSource.h
//  WeiBo(HT)
//
//  Created by mac1 on 16/8/30.
//  Copyright © 2016年 无限互联. All rights reserved.
//

#import <Foundation/Foundation.h>

//引入了AFNetworking

@interface DataSource : NSObject

+ (void) requestURL:(NSString *) urlStr
     requestHeadDic:(NSMutableDictionary *) headDic
             method:(NSString *) method
             params:(NSMutableDictionary *) params
           fileData:(NSMutableDictionary *) fileDataDic
            success:(void(^)(id responseResult))successBlock
              faile:(void(^)(NSError *error))faileBlock;


 
@end
