//
//  WeatherViewController.m
//  TianQi
//
//  Created by LM on 17/3/23.
//  Copyright © 2017年 LM. All rights reserved.
//

#import "WeatherViewController.h"

#import "DataSource.h"

#import "WeatherModel.h"
#import "ActiveData.h"
#import "WeatherData.h"

#import "WeatherView.h"

#import "MJRefresh.h"

#import "SearchViewController.h"

#import "LiveViewController.h"

#import <UMSocialCore/UMSocialCore.h>
#import <UShareUI/UShareUI.h>


@interface WeatherViewController ()

{
    
    NSMutableArray *weatherModelArr;
    NSMutableArray *activeDataArr;
    NSMutableArray *weatherDataArr;
    
    WeatherView *weatherView;

}

@property (nonatomic,copy) NSString *cityName;

@end

@implementation WeatherViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self createUI];
    
    //左上角搜索城市按钮
    [self createLeftButton];
    
    //右上角分享按钮
    [self createRightButton];
    
    [self loadData];
    
    [self createWeatherView];
    
}

/*! 设置本控制器的导航栏 */
- (void) createUI {
    
    self.cityName = @"广州";
    
    LiveViewController *liveVC = [self getVCFromResponder];
    liveVC.titleName = self.cityName;
    
    self.navigationController.navigationBar.translucent = YES;
    self.automaticallyAdjustsScrollViewInsets = YES;
    
}

/*!
 创建左上角搜索按钮
 */
- (void) createLeftButton {
    
    UIButton *leftButton = [UIButton buttonWithType:UIButtonTypeCustom];
    
    leftButton.frame = CGRectMake(0, 0, 40, 40);
    
    [leftButton setImage:[UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"btn_navbar_add@2x.png" ofType:nil]] forState:UIControlStateNormal];
    
    [leftButton addTarget:self action:@selector(leftButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:leftButton];
    
}
/*!
创建右上角分享按钮
 */
- (void) createRightButton {
    
    UIButton *rightButton = [UIButton buttonWithType:UIButtonTypeCustom];
    
    rightButton.frame = CGRectMake(0, 0, 40, 40);
    
    [rightButton setImage:[UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"btn_recomend_share_pressed.png" ofType:nil]] forState:UIControlStateNormal];
    
    [rightButton addTarget:self action:@selector(rightButtonAction) forControlEvents:UIControlEventTouchUpInside];
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:rightButton];
    
}
/*!
 左上角搜索按钮点击方法
 */
- (void) leftButtonAction :(UIButton *) button{
    
    SearchViewController *search = [[SearchViewController alloc] init];
    
    search.currentCityName = self.cityName;
    
    //__weak WeatherViewController *weakSelf = [[WeatherViewController alloc] init];
    
    //block加载刷新数据
    search.searchBlock = ^(NSString *cityName,NSString *cityCode){
        
        if(![self.cityName isEqualToString:cityName]){
            
            self.cityName = cityName;
            [self loadData];
            
            //通过响应者来寻找景点视图控制器
            if ([self getVCFromResponder]) {
                
                LiveViewController *liveVC = [self getVCFromResponder];
                
                //NSLog(@"找到了控制器");
                liveVC.cityLocation = cityCode;
                liveVC.titleName = self.cityName;
                [liveVC loadData];
            }
            
        }
        
    };
    
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:search];
    
    [self presentViewController:nav animated:YES completion:nil];
    
}

/*!
 右上角分享按钮点击方法
 */
- (void) rightButtonAction{
    
    [UMSocialUIManager showShareMenuViewInWindowWithPlatformSelectionBlock:^(UMSocialPlatformType platformType, NSDictionary *userInfo) {
        
        [self shareWebPageToPlatformType:platformType];
        
    }];
}

//分享内容到第三方平台
- (void)shareWebPageToPlatformType:(UMSocialPlatformType)platformType
{
    //设置分享内容
    WeatherData *weatherData = weatherDataArr[0];
    
    NSString *text = [NSString string];
    
    for (ActiveData *activeData in activeDataArr) {
        NSLog(@"%@",activeData.des);
        text = [text stringByAppendingString:activeData.des];
    }
    
    NSString *content = [NSString stringWithFormat:@"%@今日天气%@,气温在%@之间,%@",self.cityName,weatherData.weather,weatherData.temperature,text];

//    //创建网页内容对象
//    NSString* thumbURL =  weatherData.dayPictureUrl;

    //创建分享消息对象
    UMSocialMessageObject *messageObject = [UMSocialMessageObject messageObject];
    
    //创建网页内容对象(不可改变)
    NSString* thumbURL =  @"https://mobile.umeng.com/images/pic/home/social/img-1.png";
    
    UMShareWebpageObject *shareObject = [UMShareWebpageObject shareObjectWithTitle:@"本地今日的天气预报" descr:content thumImage:thumbURL];
    
    //设置网页地址
    shareObject.webpageUrl = @"";
    
    //分享消息对象设置分享内容对象
    messageObject.shareObject = shareObject;
    
    //调用分享接口
    [[UMSocialManager defaultManager] shareToPlatform:platformType messageObject:messageObject currentViewController:self completion:^(id data, NSError *error) {
        if (error) {
            UMSocialLogInfo(@"************Share fail with error %@*********",error);
        }else{
            if ([data isKindOfClass:[UMSocialShareResponse class]]) {
                UMSocialShareResponse *resp = data;
                //分享结果消息
                UMSocialLogInfo(@"response message is %@",resp.message);
                //第三方原始返回的数据
                UMSocialLogInfo(@"response originalResponse data is %@",resp.originalResponse);
                
            }else{
                UMSocialLogInfo(@"response data is %@",data);
            }
        }
    }];
}


/*!
 请求网络数据
 */
- (void) loadData {
 
    NSString *url = @"http://api.map.baidu.com/telematics/v3/weather";
    
    NSDictionary *dic = @{
                          @"location" : self.cityName,
                            @"output" : @"json",
                                @"ak" : @"6tYzTvGZSOpYB5Oc2YGGOKt8"
                          };
    
    NSMutableDictionary *paramDic = [[NSMutableDictionary alloc] initWithDictionary:dic];
    
    [DataSource requestURL:url requestHeadDic:nil method:@"get" params:paramDic fileData:nil success:^(id responseResult) {
        
        //NSDictionary *result = [NSJSONSerialization JSONObjectWithData:responseResult options:NSJSONReadingMutableContainers error:nil];
        
        weatherModelArr = [[NSMutableArray alloc] init];
        activeDataArr = [[NSMutableArray alloc] init];
        weatherDataArr = [[NSMutableArray alloc] init];
        
        NSMutableArray *results = responseResult[@"results"];
        
        //NSLog(@"数据：%@",results);
        WeatherModel * model = [[WeatherModel alloc] init];
        
        for (NSDictionary *dic in results) {
            [model setValueForPropertyWithDic:dic];
            [weatherModelArr addObject:model];
        }
        
        for (NSDictionary *dic in model.index) {
            ActiveData *activeData = [[ActiveData alloc] init];
            [activeData setValueForPropertyWithDic:dic];
            
            [activeDataArr addObject:activeData];
        }
        
        for (NSDictionary *dic in model.weather_data) {
            WeatherData *weatherData = [[WeatherData alloc] init];
            [weatherData setValueForPropertyWithDic:dic];
            
            [weatherDataArr addObject:weatherData];
        }
        
        self.title = model.currentCity;
        
        //加载数据成功后，判断是否存在weatherView.scroll，并且结束刷新
        if(weatherView.scroll){
         
            //数据传递
            [self getDataAndLoad];
         
            [weatherView.scroll.header endRefreshing];
        }

    } faile:^(NSError *error) {
        
        NSLog(@"请求发生错误");
    }];
}


/*!
加载本地数据
 
- (void) loadData {
    
    NSData *jsonData = [NSData dataWithContentsOfFile:[[NSBundle mainBundle] pathForResource:cityName ofType:nil]];
    
    NSDictionary *responseResult = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableContainers error:nil];

        weatherModelArr = [[NSMutableArray alloc] init];
        activeDataArr = [[NSMutableArray alloc] init];
        weatherDataArr = [[NSMutableArray alloc] init];
        
        NSMutableArray *results = responseResult[@"results"];
        
        //NSLog(@"数据：%@",results);
        WeatherModel *model = [[WeatherModel alloc] init];
        
        
        
        for (NSDictionary *dic in results) {
            [model setValueForPropertyWithDic:dic];
            [weatherModelArr addObject:model];
        }
        
        for (NSDictionary *dic in model.index) {
            ActiveData *activeData = [[ActiveData alloc] init];
            [activeData setValueForPropertyWithDic:dic];
            
            [activeDataArr addObject:activeData];
        }
        
        for (NSDictionary *dic in model.weather_data) {
            WeatherData *weatherData = [[WeatherData alloc] init];
            [weatherData setValueForPropertyWithDic:dic];
            
            [weatherDataArr addObject:weatherData];
        }
 
        self.title = model.currentCity;
    
    //加载数据成功后，判断是否存在weatherView.scroll，并且结束刷新
    if(weatherView.scroll){

        //数据传递
        [self getDataAndLoad];
 
        [weatherView.scroll.header endRefreshing];
    }
}
*/

//数据传递，天气视图获取数据并加载
- (void) getDataAndLoad {
    
    NSDictionary *dic = @{
                          
                          @"weatherModelArr":weatherModelArr,
                          @"activeDataArr":activeDataArr,
                          @"weatherDataArr":weatherDataArr
                          
                          };
    
    weatherView.dataDic = [[NSMutableDictionary alloc] initWithDictionary:dic];
    
}

/*!
 创建天气视图
 */
- (void) createWeatherView {
    
    weatherView = [[WeatherView alloc] initWithFrame:CGRectMake(0, 64, kwidth, kheight-64-49)];
    
    //创建下拉刷新
    [self createReLoadData];
    
    [self.view addSubview:weatherView];
    
    
}

/*!
 创建下拉刷新
 */
- (void) createReLoadData {
    
    weatherView.scroll.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        
        //加载本地数据使用
        //_cityName = @"data2.json";
        [self loadData];
        
    }];
    
}


//寻找响应者，获取LiveViewController
- (LiveViewController *) getVCFromResponder {
    //NSLog(@"%@",self.tabBarController.viewControllers);
    //UIResponder *responder =self.tabBarController.viewControllers[1];
    UINavigationController *nav = self.tabBarController.viewControllers[1];
    
    LiveViewController *liveVC = nav.viewControllers[0];
//    do {
//        NSLog(@"%@",nav.viewControllers);
//        if ([responder isKindOfClass:[LiveViewController class]]) {
//            
//            LiveViewController *liveVC = (LiveViewController*)responder;
//            
//            return liveVC;
//        }
//        
//        responder = responder.nextResponder;
//        
//    } while (responder);
    
    return liveVC;
}


@end
