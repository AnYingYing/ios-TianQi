//
//  MineViewController.m
//  TianQi
//
//  Created by LM on 17/3/23.
//  Copyright © 2017年 LM. All rights reserved.
//

#import "MineViewController.h"

#import "ThemeManager.h"
#import "ThemeViewController.h"

#import "SDImageCache.h"

#import "AppDelegate.h"

@interface MineViewController () <UIImagePickerControllerDelegate,UINavigationControllerDelegate>

@end

@implementation MineViewController

- (instancetype)initWithCoder:(NSCoder *)aDecoder{
    self = [super initWithCoder:aDecoder];
    if (self) {

        self.title = @"我的";
        
    }
    
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor lightGrayColor];
    
    if([UIApplication sharedApplication].scheduledLocalNotifications.count){
        
        self.notificationSwitch.on = YES;
    }
    
}
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    ThemeManager *manager =[ThemeManager shareManager];
    _themeLabel.text = manager.themeName;
    
    
    [self getAndUpdateCache];
}

//获取缓存并更新缓存标签
- (void) getAndUpdateCache {
    
    //获取缓存
    NSUInteger size = [[SDImageCache sharedImageCache] getSize];
    
    //MB--kb --b
    _cacheLabel.text = [NSString stringWithFormat:@"%.2fMB",size/1024.0/1024.0];

    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (indexPath.section ==0 && indexPath.row == 0) {
        ThemeViewController *theme = [[ThemeViewController alloc] initWithNibName:@"ThemeViewController" bundle:nil];
        theme.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:theme animated:YES];
    } else if(indexPath.section==0 && indexPath.row==1){
        
        
        UIAlertController *alertCtrl = [UIAlertController alertControllerWithTitle:@"确定清除缓存吗" message:nil preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction *ok = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            
            [[SDImageCache sharedImageCache] clearDisk];
            
            [self.tableView reloadData];
        }];
        
        UIAlertAction *no = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
            
        }];
        
        [alertCtrl addAction:ok];
        [alertCtrl addAction:no];
        
        [self presentViewController:alertCtrl animated:YES completion:nil];

    } else if(indexPath.section==1 && indexPath.row==0){
        //打开相册
        
        //相册的资源访问UIImagePickerController来读取
        UIImagePickerController *imagePickerC = [[UIImagePickerController alloc]init];
        /*
         UIImagePickerControllerSourceTypePhotoLibrary 相册
         UIImagePickerControllerSourceTypeCamera 拍照 摄像
         UIImagePickerControllerSourceTypeSavedPhotosAlbum 时刻
         */
        //数据源类型
        imagePickerC.sourceType =UIImagePickerControllerSourceTypePhotoLibrary;
        //是否允许编辑
        imagePickerC.allowsEditing = YES;
        
        imagePickerC.delegate = self;
        
        [self presentViewController:imagePickerC animated:YES completion:NULL];
        
        
    } else if(indexPath.section==3 && indexPath.row==0){
        //退出程序
        
        [self exitApplication];
        
    }
    
}

//将要显示单元格
-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (indexPath.section==0 && indexPath.row==1) {
        
        [self getAndUpdateCache];
        
    }
    
}

//退出程序
- (void)exitApplication {
    
    AppDelegate *app = [UIApplication sharedApplication].delegate;
    UIWindow *window = app.window;
    
    [UIView animateWithDuration:1.0f animations:^{
        window.alpha = 0;
        window.frame = CGRectMake(0, window.bounds.size.width, 0, 0);
    } completion:^(BOOL finished) {
        exit(0);
    }];
    
    
}

- (IBAction)notificationButtonAction:(UISwitch *) btn {
    
    if (btn.on) {//打开创建通知
        
        [self createLocalNotification];
        
    } else {//取消通知
        
        [[UIApplication sharedApplication] cancelAllLocalNotifications];
        
    }
    
}

//创建通知
- (void) createLocalNotification {
    
    //在只保留一个通知的前提下，必须先清空所有通知，然后马上创建一个
    //如果不清空所有，那么这一个唯一的通知是上一次创建的通知，不会立即生效
    [[UIApplication sharedApplication] cancelAllLocalNotifications];
    
    if (![UIApplication sharedApplication].scheduledLocalNotifications.count) {
        //创建本地通知对象
        UILocalNotification *local = [[UILocalNotification alloc] init];
        
        //设置定时推送
        NSDate *date = [NSDate dateWithTimeIntervalSinceNow:2.0];
        
        //设置通知类型
        if (local != nil) {
            
            //1 设置通知生效时间
            local.fireDate = date;
            
            //2 设置时区
            local.timeZone = [NSTimeZone defaultTimeZone];
            
            //3 设置通知的周期
            local.repeatInterval = NSCalendarUnitMinute;
            
            //4 设置推送的内容
            local.alertBody = @"新的天气数据已更新";
            
            //5 设置推送的提示音
            local.soundName = UILocalNotificationDefaultSoundName;
            
            //6 设置推送的提示数字
            local.applicationIconBadgeNumber = 1;
            
            //7 设置通知传递的参数
            local.userInfo = @{@"url":@"http://www.weather.com.cn"};
            
            //8 发送通知
            UIApplication *application = [UIApplication sharedApplication];
            
            [application scheduleLocalNotification:local];
        }
        
    }
    
}


@end
