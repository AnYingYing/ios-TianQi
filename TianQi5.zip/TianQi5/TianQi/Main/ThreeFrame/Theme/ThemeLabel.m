//
//  ThemeLabel.m
//  TianQi
//
//  Created by LM on 17/3/24.
//  Copyright © 2017年 LM. All rights reserved.
//

#import "ThemeLabel.h"

#import "ThemeManager.h"

@implementation ThemeLabel

- (void)loadColor{
    ThemeManager *manager = [ThemeManager shareManager];
    //    [self setImage:[manager getThemeImgWithImgName:_imgName] forState:UIControlStateNormal];
    
    [self setTextColor:manager.themeColor];
    
}
-(instancetype)initWithFrame:(CGRect)frame{
    
    if ([super initWithFrame:frame]) {
        
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(loadColor) name:@"ThemeChange" object:nil];
        
        [self loadColor];
    }
    return self;
}
- (instancetype)initWithCoder:(NSCoder *)aDecoder{
    
    if ([super initWithCoder:aDecoder]) {
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(loadColor) name:@"ThemeChange" object:nil];
        
        [self loadColor];
    }
    
    return self;
}
- (void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"ThemeChange" object:nil];
}


@end
