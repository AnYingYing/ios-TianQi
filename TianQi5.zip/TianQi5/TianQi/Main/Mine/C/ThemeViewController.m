//
//  ThemeViewController.m
//  Weibo62
//
//  Created by phc on 16/8/23.
//  Copyright © 2016年 phc. All rights reserved.
//

#import "ThemeViewController.h"
#import "ThemeManager.h"
@interface ThemeViewController ()<UITableViewDataSource,UITableViewDelegate>
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property(nonatomic,strong)NSArray *data;
@end

@implementation ThemeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _tableView.dataSource = self;
    _tableView.delegate =self;
    
    [self loadata];
}

- (void)loadata{
   NSString *filePath = [[NSBundle mainBundle]pathForResource:@"Theme.plist" ofType:nil];
    
   NSDictionary *dic = [NSDictionary dictionaryWithContentsOfFile:filePath];
    _data = [dic allKeys];
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section;

{
    return _data.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;{
    
    static NSString *ident = @"cell_01";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:ident];
    if (cell == nil) {
        
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:ident];
    }
    
    cell.textLabel.text = _data[indexPath.row];
    ThemeManager *manager = [ThemeManager shareManager];
    if ([_data[indexPath.row] isEqualToString:manager.themeName]) {
        cell.accessoryType = UITableViewCellAccessoryCheckmark;
    }else{
         cell.accessoryType = UITableViewCellAccessoryNone;
    }
    return cell;
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    ThemeManager *manager = [ThemeManager shareManager];
    
    manager.themeName = _data[indexPath.row];
    //manager.themeName = @"黑暗之女";
    [_tableView reloadData];
}

@end
