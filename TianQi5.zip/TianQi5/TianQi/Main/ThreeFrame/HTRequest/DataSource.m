//
//  DataSource.m
//  WeiBo(HT)
//
//  Created by mac1 on 16/8/30.
//  Copyright © 2016年 无限互联. All rights reserved.
//

#import "DataSource.h"

#import "AFNetworking.h"

#define BaseURL @"https://open.weibo.cn/2/"

@implementation DataSource

+ (void) requestURL:(NSString *) urlStr
requestHeadDic:(NSMutableDictionary *) headDic
             method:(NSString *) method
             params:(NSMutableDictionary *) params
           fileData:(NSMutableDictionary *) fileDataDic
            success:(void(^)(id responseResult))successBlock
              faile:(void(^)(NSError *error))faileBlock {
    
    //1 拼接URL
    //urlStr = [BaseURL stringByAppendingString:urlStr];
    
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    
//    [manager.requestSerializer setValue:@"gzip, deflate" forHTTPHeaderField:@"Accept-Encoding"];
//    [manager.requestSerializer setValue:@"JSESSIONID=yUucgzOFxv1WF9WC9qs7zg" forHTTPHeaderField:@"Cookie"];
    
    if (headDic != nil) {
        for (NSString *key in headDic) {
            //设置请求头
            [manager.requestSerializer setValue:[headDic objectForKey:key] forHTTPHeaderField:key];
        }
    }
    
    //判断method
    if ([method caseInsensitiveCompare:@"GET"]==NSOrderedSame) {
        
        [manager GET:urlStr parameters:params success:^(NSURLSessionDataTask * _Nonnull task, id  _Nonnull responseObject) {
            //回调block,将参数传到外界的block实现中
            successBlock(responseObject);
            
        } failure:^(NSURLSessionDataTask * _Nonnull task, NSError * _Nonnull error) {
            faileBlock(error);
        }];
        
    } else if ([method caseInsensitiveCompare:@"POST"]==NSOrderedSame) {
        
        if (fileDataDic) {
            
            [manager POST:urlStr parameters:params constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
                
                //此处的key是请求参数 例如：pic
                for (NSString *key in fileDataDic) {
                    NSData *fileData = [fileDataDic objectForKey:key];
                    
                   [formData appendPartWithFileData:fileData name:key fileName:key mimeType:@"image/tiff"];//或者 appication/octet-stream
                }
                
            } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nonnull responseObject) {
                
                successBlock(responseObject);
                
            } failure:^(NSURLSessionDataTask * _Nonnull task, NSError * _Nonnull error) {
                
                faileBlock(error);
            }];
            
        } else {
            
            [manager POST:urlStr parameters:params success:^(NSURLSessionDataTask * _Nonnull task, id  _Nonnull responseObject) {
                
                successBlock(responseObject);
            } failure:^(NSURLSessionDataTask * _Nonnull task, NSError * _Nonnull error) {
                faileBlock(error);
            }];
            
        }
    }
}


@end
