//
//  UMSocialSinaHandler.h
//  UMSocialSDK
//
//  Created by wyq.Cloudayc on 2/21/17.
//  Copyright © 2017 UMeng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <UMSocialCore/UMSocialCore.h>

@interface UMSocialSinaHandler : UMSocialHandler

+ (UMSocialSinaHandler *)defaultManager;


@end
