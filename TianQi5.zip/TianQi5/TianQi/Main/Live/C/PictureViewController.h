//
//  PictureViewController.h
//  TianQi
//
//  Created by LM on 17/3/31.
//  Copyright © 2017年 LM. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AblumView.h"

@interface PictureViewController : UIViewController <AblumViewDelegate, UIScrollViewDelegate>
{
@private
    UIImageView    *_navigationBar;
    UIScrollView   *_contentScrollView;
    UILabel        *_titleLabel;
    
}

@property (nonatomic,strong) NSMutableArray *imagesData;

@property (nonatomic,assign) NSInteger selectedNum;



@end
