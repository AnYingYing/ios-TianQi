//
//  weatherTwoCollectionCell.m
//  TianQi
//
//  Created by LM on 17/4/5.
//  Copyright © 2017年 LM. All rights reserved.
//

#import "weatherTwoCollectionCell.h"

#import "ThemeLabel.h"

@interface weatherTwoCollectionCell () {
    
    __weak IBOutlet UIImageView *imgView;
    
    __weak IBOutlet ThemeLabel *tiptLabel;
    
    __weak IBOutlet ThemeLabel *zsLabel;
    
}

@end

@implementation weatherTwoCollectionCell

- (void)setActiveData:(ActiveData *)activeData {
    
    _activeData = activeData;
    
    imgView.image = [UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:[NSString stringWithFormat:@"%@.png",activeData.title] ofType:nil]];
    
    tiptLabel.text = activeData.tipt;
    zsLabel.text = activeData.zs;
    
}

- (void)awakeFromNib {
    //imgView.backgroundColor = [UIColor colorWithWhite:20/255.0 alpha:0.2];
    imgView.layer.cornerRadius = 10;
    imgView.layer.masksToBounds = YES;
    
    self.backgroundColor = [UIColor colorWithWhite:20/255.0 alpha:0.2];
    self.layer.cornerRadius = 8;
}

@end
