//
//  ThemeImgView.m
//  TianQi
//
//  Created by LM on 17/3/23.
//  Copyright © 2017年 LM. All rights reserved.
#import "ThemeImgView.h"
#import "ThemeManager.h"
@implementation ThemeImgView

-(void)setImgName:(NSString *)imgName{
    
    if (_imgName != imgName) {
        _imgName = imgName;
        
        [self loadImg];
    }
}
- (void)loadImg{
    ThemeManager *manager = [ThemeManager shareManager];
//    [self setImage:[manager getThemeImgWithImgName:_imgName] forState:UIControlStateNormal];

    UIImage *img =[manager getThemeImgWithImgName:_imgName];
    
    if (!img) {
        NSLog(@"没找到图片，选择默认");
        img = [UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"default.jpg" ofType:nil]];
    }
    
   self.image = [img stretchableImageWithLeftCapWidth:30 topCapHeight:30];
}
-(instancetype)initWithFrame:(CGRect)frame{
    
    if ([super initWithFrame:frame]) {
        
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(loadImg) name:@"ThemeChange" object:nil];
        
    }
    return self;
}
- (instancetype)initWithCoder:(NSCoder *)aDecoder{

    if ([super initWithCoder:aDecoder]) {
     [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(loadImg) name:@"ThemeChange" object:nil];
    }
    
    return self;
}
- (void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"ThemeChange" object:nil];
}


@end
