//
//  BaseTabViewController.m
//  MiTao
//
//  Created by LM on 17/3/20.
//  Copyright © 2017年 LM. All rights reserved.
//

#import "BaseTabViewController.h"

@interface BaseTabViewController ()

@end

@implementation BaseTabViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //1. 添加故事板
    [self createStoryBoard];
    
    //2. 移除自带按钮
    [self removeOwnerSubLayer];
    
    //3. 标签栏添加自定义子视图
    [self createTabBarSubView];
}

- (void) createStoryBoard {
    
    //1. 加载故事板
    UIStoryboard *weatherStory = [UIStoryboard storyboardWithName:@"Weather" bundle:nil];
    
    UIStoryboard *liveStory = [UIStoryboard storyboardWithName:@"Live" bundle:nil];
    
    UIStoryboard *mineStory = [UIStoryboard storyboardWithName:@"Mine" bundle:nil];
    
    //2. 加载导航控制器，将故事版入口控制器放入数组中
    NSArray *navCtrs = @[
                         [weatherStory instantiateInitialViewController],
                         [liveStory instantiateInitialViewController],
                         [mineStory instantiateInitialViewController]
                         ];
    
    self.viewControllers = navCtrs;
    
}

- (void) removeOwnerSubLayer {
    
    for (UIView *view in self.tabBar.subviews) {
        if ([view isKindOfClass:NSClassFromString(@"UITabBarButton")]) {
            [view removeFromSuperview];
        }
    }
    
}

- (void) createTabBarSubView {
    
    //拉伸图片
    UIEdgeInsets insets = UIEdgeInsetsMake(0, 22, 0, 22);
    
    UIImage *image = [UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"bg_tab_normal@2x.png" ofType:nil]];
    
    UIImage *img =[image resizableImageWithCapInsets:insets resizingMode:UIImageResizingModeStretch];
    
    UIImageView *imgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, kwidth,49)];
    
    imgView.backgroundColor = [UIColor greenColor];
    
    imgView.image = img;
    
    [self.tabBar addSubview:imgView];
    
    NSArray *imgArr = @[
                        @"ic_tab_weather_",
                        @"ic_tab_live_",
                        @"ic_tab_me_"
                        ];
    
    CGFloat width = kwidth/imgArr.count * 1.0;
    
    for (int i=0; i<imgArr.count; i++) {
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        
        btn.frame = CGRectMake(i*width, 0, width, 49);
        
        [btn setImage:[UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:[NSString stringWithFormat:@"%@normal@2x.png",imgArr[i]] ofType:nil]] forState:UIControlStateNormal];
        
        [btn setImage:[UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:[NSString stringWithFormat:@"%@pressed@2x.png",imgArr[i]] ofType:nil]] forState:UIControlStateSelected];
        
        [btn addTarget:self action:@selector(buttonAction:) forControlEvents:UIControlEventTouchUpInside];
        
        btn.tag = 1000 + i;
        
        if (i==0) {
            btn.selected = YES;
            self.selectedIndex = i;
        }
        
        [self.tabBar addSubview:btn];
    }
}

- (void) buttonAction:(UIButton *) btn {
    
    self.selectedIndex = btn.tag - 1000;
    
    for (int i=0; i<self.viewControllers.count; i++) {
        UIButton *button = [self.tabBar viewWithTag:1000+i];
        button.selected = NO;
    }
    
    btn.selected = YES;
}

@end
