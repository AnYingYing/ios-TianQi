//
//  weatherOneCollectionCell.h
//  TianQi
//
//  Created by LM on 17/4/5.
//  Copyright © 2017年 LM. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "weatherData.h"

@interface weatherOneCollectionCell : UICollectionViewCell

@property (nonatomic,strong) WeatherData *weatherData;

@end
