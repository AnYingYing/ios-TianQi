//
//  SearchViewController.m
//  TianQi
//
//  Created by LM on 17/4/1.
//  Copyright © 2017年 LM. All rights reserved.
//

#import "SearchViewController.h"

#import "SearchModel.h"

#import "SearchTableView.h"

#import "DataSource.h"

#import <CoreLocation/CoreLocation.h>

@interface SearchViewController () <CLLocationManagerDelegate>

@property (nonatomic,strong) SearchTableView *searchTableView;

@property (nonatomic,strong) CLLocationManager *manager;

@end

@implementation SearchViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //初始化集合视图
    [self setupCollectionView];
    
    [self.collectionView reloadData];
    
    [self createSearchBox];
    
    [self createLeftCancelButton];
    
    [self createSearchTableView];
    
}

//创建输入框输入城市时弹出来的表视图
- (void) createSearchTableView {
    
    _searchTableView = [[SearchTableView alloc] initWithFrame:CGRectMake(0, 0, 0, 0)];
    
    __weak SearchViewController *weakSelf = self;
    
    _searchTableView.webblock = ^(NSString *cityName,NSString *cityCode){
        
        weakSelf.searchBlock(cityName,cityCode);
        
        [weakSelf cancelAction];
        
    };
    
    [self.view addSubview:_searchTableView];
}


//创建导航栏搜索框
- (void) createSearchBox {
    
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(60, 0, kwidth-60, 30)];
    self.navigationItem.titleView = view;
    
    //
    UIImageView *imgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, kwidth-110, 40-10)];
    
    imgView.userInteractionEnabled = YES;
    
    imgView.image = [UIImage imageNamed:@"search_bg@2x"];
    
    [view addSubview:imgView];
    //
    UIImageView *smallImgView = [[UIImageView alloc] initWithFrame:CGRectMake(15, 5, 25, 25)];
    
    smallImgView.image = [UIImage imageNamed:@"search_indicator@2x"];
    
    [imgView addSubview:smallImgView];
    //
    _textF = [[UITextField alloc] initWithFrame:CGRectMake(50, 0, imgView.frame.size.width-50, imgView.frame.size.height)];
    
    _textF.clearButtonMode = UITextFieldViewModeWhileEditing;
    
    [_textF addTarget:self action:@selector(textFieldSearchAction:) forControlEvents:UIControlEventEditingChanged];
    
    [imgView addSubview:_textF];
    //
    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    
    button.frame = CGRectMake(imgView.width, 0, 40, 40);
    
    [button setTitle:@"取消" forState:UIControlStateNormal];
    [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [button addTarget:self action:@selector(rightBtnAction) forControlEvents:UIControlEventTouchUpInside];
    
    //[imgView addSubview:button];//按钮添加在ImgView上就点击不了
    [view addSubview:button];
}

//取消按钮方法,取消输入框的第一响应者
- (void) rightBtnAction {
    
    //取消第一响应者
    [_textF resignFirstResponder];
    
    _searchTableView.frame = CGRectMake(0, 0, 0, 0);
    
}


- (void)createLeftCancelButton {
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    
    button.frame = CGRectMake(0, 0, 40, 40);
    
    [button setTitle:@"返回" forState:UIControlStateNormal];
    
    [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [button addTarget:self action:@selector(cancelAction) forControlEvents:UIControlEventTouchUpInside];
    
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:button];
    
}

- (void) cancelAction {
    
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void) textFieldSearchAction:(UITextField *) textF {
    
    NSString *text = textF.text;
    
    if (text.length==0) {
        
        [UIView animateWithDuration:0.5 animations:^{
            
            _searchTableView.frame = CGRectMake(0, 64, 0, 0);
            
        }];
        
    } else {
        
        //    NSString *filterString = [NSString stringWithFormat:@"SELF LIKE[c] '%@*'",text];
        //
        //    NSPredicate *pre = [NSPredicate predicateWithFormat:filterString];
        //
        //
        //
        //    self.filterArray = [self.otherSearchs filteredArrayUsingPredicate:pre];
        
        
        //[self loadDataWithSearchText:text];
        
        [self loadDataWithSearchText:text];
        
        [UIView animateWithDuration:0.5 animations:^{
            
            _searchTableView.frame = CGRectMake(0, 64, kwidth, kheight-64);
            
        }];
    }
}


/*! 刷新请求数据 */
- (void) loadDataWithSearchText:(NSString *) text {
    
    NSString *url = [NSString stringWithFormat:@"http://open.weather.sina.com.cn/api/location/getIndexSuggestion/%@",text];
    
    //将URL中的中文转码
    url = [url stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
    
    [DataSource requestURL:url requestHeadDic:nil method:@"get" params:nil fileData:nil success:^(id responseResult) {
        
        //NSDictionary *result = [NSJSONSerialization JSONObjectWithData:responseResult options:NSJSONReadingMutableContainers error:nil];
        
        
        NSMutableArray *results = responseResult[@"result"][@"data"];
        
        //NSLog(@"数据：%@",results);
        
        
        NSMutableArray *searchDataArray = [[NSMutableArray alloc] init];
        
        for (NSDictionary *dic in results) {
            SearchModel * model = [[SearchModel alloc] init];
            [model setValueForPropertyWithDic:dic];
            [searchDataArray addObject:model];
        }
        
        _searchTableView.dataArray = searchDataArray;
        
        [_searchTableView reloadData];
        
    } faile:^(NSError *error) {
        
        //NSLog(@"请求发生错误");
        
    }];
    
}
/*
 
 //对中文转码
 urlStr = [urlStr stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
 
 如果知道url中的中文既可能已经转码，也可能没有转码，那么使用如下的方法，当不管url中的中文是否已经utf-8转码了，都可以解决将中文字符转为utf-8的问题，且不是二次转码
 
 NSLog(@"原url:%@", url);
 NSString *encodedString = (NSString *)
 CFBridgingRelease(CFURLCreateStringByAddingPercentEscapes(kCFAllocatorDefault,
 
 (CFStringRef)url,
 
 (CFStringRef)@"!$&'()*+,-./:;=?@_~%#[]",
 
 NULL,
 
 kCFStringEncodingUTF8));
 
 NSLog(@"转码url:%@",  encodedString);
 
 */

//-----------------------搜索功能:集合视图---------------------

static NSString * const collectionCellID = @"ChannelCollectionCell";
static NSString * const collectionViewSectionHeaderID = @"ChannelCollectionHeader";

//-----------------数据----------------------------------
#pragma mark --懒加载--allChannelsArray
-(NSMutableArray *)allChannelsArray {
    if (!_allChannelsArray) {
        _allChannelsArray = [NSMutableArray array];
        NSArray *tempArray = [[NSUserDefaults standardUserDefaults] objectForKey:@"allChannelsArray"];
        [_allChannelsArray addObjectsFromArray:tempArray];
        if (_allChannelsArray.count == 0) {
            [_allChannelsArray addObjectsFromArray:@[@"北京",@"上海",@"长沙",@"广州",@"深圳",@"沈阳",@"郑州",@"杭州",@"成都",@"重庆",@"拉萨",@"永州",@"福州",@"南昌",@"武汉",@"香港",@"厦门",@"岳阳",@"太原",@"长春"]];
            [[NSUserDefaults standardUserDefaults] setObject:_allChannelsArray forKey:@"allChannelsArray"];
            [[NSUserDefaults standardUserDefaults] synchronize];
        }
        
    }
    return _allChannelsArray;
}

//-----------------------视图---------------------------------


//-------------初始化创建需要弹出的collectionView-------------
#pragma mark --private Method--初始化点击加号按钮弹出的新闻频道编辑的CollectionView
-(void)setupCollectionView {
    //集合视图
    UICollectionViewFlowLayout *flowLayout = [[UICollectionViewFlowLayout alloc] init];
    flowLayout.scrollDirection = UICollectionViewScrollDirectionVertical;
    flowLayout.headerReferenceSize = CGSizeMake([UIScreen mainScreen].bounds.size.width, 35);//每组头部
    UICollectionView *collectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(0, 0, kwidth, self.view.bounds.size.height) collectionViewLayout:flowLayout];
    
    self.collectionView = collectionView;
    collectionView.backgroundColor = [UIColor colorWithRed:25.0/255 green:57.0/255 blue:95.0/255 alpha:1];
    collectionView.alpha = 0.98;
    [self.view addSubview:collectionView];
    collectionView.dataSource = self;
    collectionView.delegate = self;
    
    [collectionView registerNib:[UINib nibWithNibName:NSStringFromClass([ChannelCollectionViewCell class]) bundle:nil] forCellWithReuseIdentifier:collectionCellID];
    
    [collectionView registerClass:[ChannelsSectionHeaderView class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:collectionViewSectionHeaderID];
    
}

#pragma mark --UICollectionViewDataSource-- 返回collectionView的cell是否能被选中
-(BOOL)collectionView:(UICollectionView *)collectionView shouldSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}

#pragma mark --UICollectionViewDataSource-- 返回collectionView的组标题View
- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath {
    ChannelsSectionHeaderView *headerView = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:collectionViewSectionHeaderID forIndexPath:indexPath];
    if (indexPath.section == 0) {
        headerView.titleLabel.text = @"自动获取用户所在城市";
        
    }else if (indexPath.section == 1) {
        headerView.titleLabel.text = @"当前城市";
    }else if (indexPath.section == 2) {
        headerView.titleLabel.text = @"推荐城市";
    }

    return headerView;
}

#pragma mark --UICollectionViewDataSource-- 返回collectionView的组数
-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 3;
}

#pragma mark --UICollectionViewDataSource-- 返回collectionView的每一组对应的cell个数
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    
    if (section==0 || section==1) {
        return 1;
    }
    
    return self.allChannelsArray.count;
    
}

#pragma mark --UICollectionViewDataSource-- 返回collectionView每个indexpath对应的cell
-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    ChannelCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:collectionCellID forIndexPath:indexPath];
    
    cell.layer.cornerRadius = 15;
    cell.layer.borderWidth = 1;
    cell.layer.borderColor = [UIColor blackColor].CGColor;
    
    if (indexPath.section == 0) {
        cell.channelName = @"自动定位";
    }else if (indexPath.section == 1) {
        cell.channelName = self.currentCityName;
    }else {
        cell.channelName = self.allChannelsArray[indexPath.row];
    }
    
    return cell;
    
}

#pragma mark --UICollectionViewDataSource-- 返回每个UICollectionViewCell发Size
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    CGFloat kDeviceWidth = [UIScreen mainScreen].bounds.size.width;
    CGFloat kMargin = 10;
    return CGSizeMake((kDeviceWidth - 5*kMargin)/4, 40);
}

#pragma mark --UICollectionViewDataSource-- 返回collectionView每一组的外边距
-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(10, 10, 10, 10);
}

#pragma mark --UICollectionViewDataSource-- 返回collectionView每个item之间的最小间距
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section {
    return 10;
}

//-----------------点击单元格调用的方法-------------------

#pragma mark --UICollectionViewDelegate-- 点击了某个UICollectionViewCell
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    
    
    if (indexPath.section == 0) {//点击的是第一组的cell
        
        //自动定位
        [self autolocationAction];
        
    } else if (indexPath.section == 1){
        
        [self cancelAction];
        
    } else {
        
        [self loadWithCollection:self.allChannelsArray[indexPath.row]];
        
    }
    //[self cancelAction];//会打断定位授权
}

//集合视图单元格点击请求数据
- (void) loadWithCollection:(NSString *) text {

    NSString *url = [NSString stringWithFormat:@"http://open.weather.sina.com.cn/api/location/getIndexSuggestion/%@",text];
    
    //将URL中的中文转码
    url = [url stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
    
    [DataSource requestURL:url requestHeadDic:nil method:@"get" params:nil fileData:nil success:^(id responseResult) {
        
        NSMutableArray *results = responseResult[@"result"][@"data"];
        
        for (NSDictionary *dic in results) {
            SearchModel * model = [[SearchModel alloc] init];
            [model setValueForPropertyWithDic:dic];
            
            if ([model.chinese_name isEqualToString:text]) {
                
                self.searchBlock(model.chinese_name,model.loc_code);
            }
        }
        
        //返回天气界面
        [self cancelAction];
        
    } faile:^(NSError *error) {
        
        NSLog(@"集合视图请求发生错误");
    }];
}
//--自动定位:先配置Plist，注意必须将CLLocationManager对象设置为全局--

- (void) autolocationAction {
    
     _manager = [[CLLocationManager alloc] init];
    
    //判断是否打开定位
    if ([CLLocationManager locationServicesEnabled]) {
        //是否授权
        if ([CLLocationManager authorizationStatus]!=kCLAuthorizationStatusAuthorizedWhenInUse) {
            
            //弹出窗口请求用户授权
            [_manager requestWhenInUseAuthorization];
            
            
            
            //允许在前台获取GPS的描述
            //[_manager requestAlwaysAuthorization];
            //允许在前台获取GPS的描述
            //[_manager requestWhenInUseAuthorization];
        }
    }
    
    _manager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters;
    
    //设置代理
    _manager.delegate = self;
    
    //开启定位
    [_manager startUpdatingLocation];
    
    num = 0;
}

/*取得的经纬度总是上一次的，所以我在这里让获取定位的代理方法走两次，
   并且打印出经纬度，发现打印了两次，第一次是上一次的，第二次是新的
经纬度,直到调用4次才正确，为以防万一，此处我调用5次,我猜测与不同线程有关。
 */
 static NSInteger num;

//代理方法
- (void)locationManager:(CLLocationManager *)manager
     didUpdateLocations:(NSArray<CLLocation *> *)locations {
    
    num++;
    
    //打印两次的经纬度
    //CLLocation *location = [locations lastObject];
    //CLLocationCoordinate2D coordinate2D = location.coordinate;
    //NSLog(@"第%ld次：%lf,%lf",num,coordinate2D.latitude,coordinate2D.longitude);
    
    
    if (num==5) {
        
        CLLocation *location = [locations lastObject];
        CLLocationCoordinate2D coordinate2D = location.coordinate;
        
        [_manager stopUpdatingLocation];
        _manager = nil;
        
        [self loadData:coordinate2D];
    }
    
    //调用新浪接口请求附近发送微博的用户信息，请求参数需要经纬度
    //[self loadData:coordinate2D];
    
}
- (void) loadData:(CLLocationCoordinate2D) coordinate {
    
    NSLog(@"经度%lf，纬度%lf",coordinate.longitude,coordinate.latitude);
    
    NSString *urlStr = @"http://maps.google.cn/maps/api/geocode/json";
    
    NSDictionary *params = @{
                             @"latlng":[NSString stringWithFormat:@"%lf,%lf",coordinate.latitude,coordinate.longitude],
                             @"language":@"CN"
                             };
    
    [DataSource requestURL:urlStr requestHeadDic:nil method:@"GET" params:[[NSMutableDictionary alloc] initWithDictionary:params] fileData:nil success:^(id responseResult) {
        
        //NSLog(@"%@",responseResult);
        
        NSArray *dataArr = responseResult[@"results"];
        NSDictionary *dic = [dataArr firstObject];
        
        NSArray *arr = dic[@"address_components"];
        
        NSDictionary *cityNameDic = arr[2];
        NSDictionary *parentCityDic = arr[3];
        
        //NSArray *locationArr = [cityLocation componentsSeparatedByString:@" "];
        
        NSString *cityName = cityNameDic[@"long_name"];
        NSString *parentCity = parentCityDic[@"long_name"];
        
        NSLog(@"%@:%@",parentCity,cityName);
        [self loadWithCollection:[cityName substringToIndex:2]];
        
    } faile:^(NSError *error) {
        NSLog(@"%@",error);
    }];
    
}



@end
