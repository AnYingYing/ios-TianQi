//
//  weatherTwoCollectionCell.h
//  TianQi
//
//  Created by LM on 17/4/5.
//  Copyright © 2017年 LM. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ActiveData.h"

@interface weatherTwoCollectionCell : UICollectionViewCell

@property (nonatomic,strong) ActiveData *activeData;

@end
