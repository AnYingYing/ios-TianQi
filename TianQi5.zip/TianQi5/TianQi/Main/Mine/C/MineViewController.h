//
//  MineViewController.h
//  TianQi
//
//  Created by LM on 17/3/23.
//  Copyright © 2017年 LM. All rights reserved.
//

#import "BaseViewController.h"

@interface MineViewController : UITableViewController

@property (weak, nonatomic) IBOutlet UIImageView *row1ImgView;
@property (weak, nonatomic) IBOutlet UIImageView *row2ImgView;
@property (weak, nonatomic) IBOutlet UIImageView *row3ImgView;
@property (weak, nonatomic) IBOutlet UILabel *themeLabel;
@property (weak, nonatomic) IBOutlet UILabel *cacheLabel;

@property (weak, nonatomic) IBOutlet UISwitch *notificationSwitch;
@end
