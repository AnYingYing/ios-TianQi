//
//  ThemeViewController.h
//  Weibo62
//
//  Created by phc on 16/8/23.
//  Copyright © 2016年 phc. All rights reserved.
//

#import "BaseViewController.h"

@interface ThemeViewController : BaseViewController

@end
