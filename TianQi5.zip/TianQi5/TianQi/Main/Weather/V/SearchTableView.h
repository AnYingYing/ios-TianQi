//
//  SearchTableView.h
//  Project3
//
//  Created by mac1 on 16/9/10.
//  Copyright © 2016年 无限互联. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void (^WebBlock)(NSString *cityName,NSString *cityCode);

@interface SearchTableView : UITableView <UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong)NSMutableArray *dataArray;


@property (nonatomic, copy) WebBlock webblock;

@end
