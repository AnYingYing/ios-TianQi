//
//  MoreView.m
//  TianQi
//
//  Created by LM on 17/3/31.
//  Copyright © 2017年 LM. All rights reserved.
//

#import "MoreView.h"
#import <QuartzCore/QuartzCore.h>

#import "UIViewExt.h"

@implementation MoreView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        _imageNames = [NSArray arrayWithObjects:@"原始",@"lomo",@"黑白",@"怀旧",@"哥特",@"淡雅",@"酒红",@"清宁",@"浪漫",@"光晕",@"蓝调",@"梦幻",@"夜色", nil];
        
        self.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.5];
    
        _popView = [[UIImageView alloc] initWithFrame:CGRectMake(kwidth-145-10, 64, 145, 46*_imageNames.count)];
        _popView.userInteractionEnabled = YES;
        _popView.image = [UIImage imageNamed:@"moreView_setting_new"];
        //围绕X轴翻转180
        _popView.layer.transform = CATransform3DMakeRotation(M_PI, 1, 0, 0);
        
        [self addSubview:_popView];
        
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, -5, _popView.width, _popView.height-15) style:UITableViewStylePlain];
        _tableView.layer.cornerRadius = 5;
        _tableView.scrollEnabled = NO;
        _tableView.backgroundColor = [UIColor clearColor];
        _tableView.dataSource = self;
        _tableView.delegate = self;
        [_popView addSubview:_tableView];
        
        _tableView.layer.transform = CATransform3DMakeRotation(M_PI, 1, 0, 0);
        
    }
    return self;
}


#pragma mark - TableView DataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _imageNames.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
    cell.contentView.backgroundColor = [UIColor blackColor];
    cell.textLabel.textColor = [UIColor whiteColor];
    
    cell.imageView.image = [UIImage imageNamed:@"more_search"];//
    cell.textLabel.text = _imageNames[indexPath.row];
    
    
    return cell;
}

#pragma mark - TableView Delegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([self.delegate respondsToSelector:@selector(didSelectTableViewCellIndex:)]) {
        [self.delegate didSelectTableViewCellIndex:indexPath.row];
    }
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    if ([self.delegate respondsToSelector:@selector(didMoreViewBackgoundWithTag:)]) {
        [self.delegate didMoreViewBackgoundWithTag:self.tag];
    }
}


@end
