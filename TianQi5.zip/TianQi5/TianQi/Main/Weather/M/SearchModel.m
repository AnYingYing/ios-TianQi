//
//  SearchModel.m
//  TianQi
//
//  Created by LM on 17/4/2.
//  Copyright © 2017年 LM. All rights reserved.
//

#import "SearchModel.h"

@implementation SearchModel

@end
