//
//  ThemeManager.h
//  TianQi
//
//  Created by LM on 17/3/23.
//  Copyright © 2017年 LM. All rights reserved.

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface ThemeManager : NSObject
@property(nonatomic,copy)NSString *themeName;
@property(nonatomic,strong)NSDictionary *colorDic;

//------------
@property (nonatomic,strong) UIColor *themeColor;
//------------

+(id)shareManager;

//照图片
-(UIImage *)getThemeImgWithImgName:(NSString *)imgName;

- (UIColor *)getThemeColorWithColorName:(NSString *)colorName;
@end
