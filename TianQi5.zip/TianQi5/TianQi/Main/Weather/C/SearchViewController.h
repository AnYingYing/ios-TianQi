//
//  SearchViewController.h
//  TianQi
//
//  Created by LM on 17/4/1.
//  Copyright © 2017年 LM. All rights reserved.
//

#import <UIKit/UIKit.h>

//collectionView的景点头视图
#import "ChannelsSectionHeaderView.h"

#import "ChannelCollectionViewCell.h"
#import "UIViewExt.h"


typedef void(^SearchBlock)(NSString *cityName,NSString *cityCode);


@interface SearchViewController : UIViewController<UICollectionViewDataSource,UICollectionViewDelegate>


@property (nonatomic, weak) UICollectionView *collectionView;

//当前推荐的城市名
@property (nonatomic, strong) NSMutableArray *allChannelsArray;

@property (nonatomic, copy) NSString *currentCityName;

//输入文本框
@property (nonatomic, strong) UITextField *textF;


@property (nonatomic, copy) SearchBlock searchBlock;

@end
