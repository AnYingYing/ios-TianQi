//
//  ChannelCollectionViewCell.m
//  TTNews
//
//  Created by 瑞文戴尔 on 16/3/30.
//  Copyright © 2016年 瑞文戴尔. All rights reserved.
//

#import "ChannelCollectionViewCell.h"


@interface ChannelCollectionViewCell()


@end

static NSString * const kShakeAnimationKey = @"kCollectionViewCellShake";

@implementation ChannelCollectionViewCell

- (void)awakeFromNib {
    

}




-(void)setChannelName:(NSString *)channelName {
    _channelName = channelName;

    self.channelNameLabel.text = channelName;
}

@end
