//
//  MoreView.h
//  TianQi
//
//  Created by LM on 17/3/31.
//  Copyright © 2017年 LM. All rights reserved.
//

//-----情景模式视图
#import <UIKit/UIKit.h>

@protocol MoreViewDelegate <NSObject>

// 用户点击背景视图
- (void)didMoreViewBackgoundWithTag:(NSInteger)tag;

// 用户点击表视图
- (void)didSelectTableViewCellIndex:(NSInteger)index;

@end

@interface MoreView : UIView <UITableViewDelegate, UITableViewDataSource>
{
@private
    UITableView *_tableView;
    
    NSArray *_imageNames;
}

@property (nonatomic, assign) id <MoreViewDelegate> delegate;

@property (nonatomic, strong) UIImageView *popView;;

@end
