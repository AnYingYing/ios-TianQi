//
//  SearchModel.h
//  TianQi
//
//  Created by LM on 17/4/2.
//  Copyright © 2017年 LM. All rights reserved.
//

#import "BaseModel.h"

/*
 
 //搜索框搜索以及提示
 //http://open.weather.sina.com.cn/api/location/getIndexSuggestion/长
 
 {"result":{"status":{"code":0,"msg":"success"},"timestamp":"Sun Apr 02 13:17:45 +0800 2017","data":[{"loc_code":"43-48-30-36-30-31-30-31","name":"","type":"1","url":"changchun","chinese_name":"\u957f\u6625","parent_name":"\u5409\u6797"},
 
 */

@interface SearchModel : BaseModel

/*! 地区码 */
@property (nonatomic,copy) NSString *loc_code;
/*! 未知 */
@property (nonatomic,copy) NSString *name;
/*! 类型 */
@property (nonatomic,copy) NSString *type;
/*! url */
@property (nonatomic,copy) NSString *url;
/*! 搜索的城市名 */
@property (nonatomic,copy) NSString *chinese_name;
/*! 该城市隶属于的城市名（上一级城市） */
@property (nonatomic,copy) NSString *parent_name;

@end
