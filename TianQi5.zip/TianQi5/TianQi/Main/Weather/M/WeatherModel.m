//
//  WeatherModel.m
//  TianQi
//
//  Created by LM on 17/3/23.
//  Copyright © 2017年 LM. All rights reserved.
//

#import "WeatherModel.h"

@implementation WeatherModel


//- (instancetype)init
//{
//    self = [super init];
//    if (self) {
//        
//        //self.activeData = [[ActiveData alloc] init];
//        //self.weatherData = [[WeatherData alloc] init];
//        
//    }
//    return self;
//}
//
//- (ActiveData *)activeData {
//    
//    for (NSDictionary *dic in self.index) {
//        [self.activeData setValueForPropertyWithDic:dic];
//    }
//    
//    return self.activeData;
//    
//}
//
//- (WeatherData *)weatherData {
//    
//    for (NSDictionary *dic in self.weather_data) {
//        [self.weatherData setValueForPropertyWithDic:dic];
//    }
//    
//    return _weatherData;
//}


@end
