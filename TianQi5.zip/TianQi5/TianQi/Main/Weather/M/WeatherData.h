//
//  WeatherData.h
//  TianQi
//
//  Created by LM on 17/3/23.
//  Copyright © 2017年 LM. All rights reserved.
//

#import "BaseModel.h"

/*
 
 "weather_data": [
 {
 "date": "周四 03月23日 (实时：25℃)",
 "dayPictureUrl": "http://api.map.baidu.com/images/weather/day/yin.png",
 "nightPictureUrl": "http://api.map.baidu.com/images/weather/night/duoyun.png",
 "weather": "阴转多云",
 "wind": "微风",
 "temperature": "25 ~ 19℃"
 },
 {
 "date": "周五",
 "dayPictureUrl": "http://api.map.baidu.com/images/weather/day/yin.png",
 "nightPictureUrl": "http://api.map.baidu.com/images/weather/night/xiaoyu.png",
 "weather": "阴转小雨",
 "wind": "微风",
 "temperature": "25 ~ 17℃"
 },
 {
 "date": "周六",
 "dayPictureUrl": "http://api.map.baidu.com/images/weather/day/xiaoyu.png",
 "nightPictureUrl": "http://api.map.baidu.com/images/weather/night/dayu.png",
 "weather": "小雨转中到大雨",
 "wind": "北风3-4级",
 "temperature": "17 ~ 12℃"
 },
 {
 "date": "周日",
 "dayPictureUrl": "http://api.map.baidu.com/images/weather/day/dayu.png",
 "nightPictureUrl": "http://api.map.baidu.com/images/weather/night/duoyun.png",
 "weather": "中到大雨转多云",
 "wind": "微风",
 "temperature": "17 ~ 10℃"
 }
 ]
 
 */

@interface WeatherData : BaseModel

@property (nonatomic,copy) NSString *date;//星期几
@property (nonatomic,copy) NSString *dayPictureUrl;
@property (nonatomic,copy) NSString *nightPictureUrl;
@property (nonatomic,copy) NSString *weather;//天气
@property (nonatomic,copy) NSString *wind;//风的强度
@property (nonatomic,copy) NSString *temperature;//气温范围

@end
