//
//  LiveViewController.h
//  MiTao
//
//  Created by LM on 17/3/20.
//  Copyright © 2017年 LM. All rights reserved.
//

#import "BaseViewController.h"

@interface LiveViewController : BaseViewController
/*! 城市 */
@property (nonatomic,copy) NSString *cityLocation;
/*! 当前页数 */
@property (nonatomic,assign) NSInteger pageNum;
/*! 当前页图片数量 */
@property (nonatomic,assign) NSInteger picSum;

/*! 标题名 */
@property (nonatomic,copy) NSString *titleName;



- (void) loadData;

@end
