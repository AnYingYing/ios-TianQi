//
//  WeatherView.h
//  TianQi
//
//  Created by LM on 17/3/23.
//  Copyright © 2017年 LM. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WeatherView : UIView

@property (nonatomic,strong) NSMutableDictionary *dataDic;

@property (nonatomic,strong) UIScrollView *scroll;


@end
