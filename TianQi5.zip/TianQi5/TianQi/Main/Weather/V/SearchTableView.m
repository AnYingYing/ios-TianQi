//
//  SearchTableView.m
//  Project3
//
//  Created by mac1 on 16/9/10.
//  Copyright © 2016年 无限互联. All rights reserved.
//

#import "SearchTableView.h"

#import "SearchModel.h"

@implementation SearchTableView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        [self createUI];
        
    }
    return self;
}

- (void) createUI {
    
    self.rowHeight = 100;
    self.delegate = self;
    self.dataSource = self;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *cellID = @"cellID";
    
//    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
//    
//    if (cell == nil) {
//        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
//    }
    
    UITableViewCell *cell = [[UITableViewCell alloc] init];
    
    SearchModel *model = self.dataArray[indexPath.row];

    UILabel *nameLabel = [[UILabel alloc] initWithFrame:CGRectMake(5, 5, 200, 40)];
    nameLabel.text = model.chinese_name;
    nameLabel.font = [UIFont systemFontOfSize:20];
    [cell.contentView addSubview:nameLabel];
    
    UILabel *parentNameLabel = [[UILabel alloc] initWithFrame:CGRectMake(kwidth-200, 50, 200, 40)];
    parentNameLabel.text = [NSString stringWithFormat:@"所在省: %@",model.parent_name];
    [cell.contentView addSubview:parentNameLabel];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    SearchModel *model = self.dataArray[indexPath.row];
    
    NSString *cityName = model.chinese_name;
    
    NSString *cityCode = model.loc_code;
    
    self.webblock(cityName,cityCode);
    
}


@end
