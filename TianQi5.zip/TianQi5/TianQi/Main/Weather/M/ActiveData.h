//
//  ActiveData.h
//  TianQi
//
//  Created by LM on 17/3/23.
//  Copyright © 2017年 LM. All rights reserved.
//

#import "BaseModel.h"

/*
 
 "index": [
 {
 "title": "穿衣",
 "zs": "较舒适",
 "tipt": "穿衣指数",
 "des": "建议着薄外套、开衫牛仔衫裤等服装。年老体弱者应适当添加衣物，宜着夹克衫、薄毛衣等。"
 },
 {
 "title": "洗车",
 "zs": "较适宜",
 "tipt": "洗车指数",
 "des": "较适宜洗车，未来一天无雨，风力较小，擦洗一新的汽车至少能保持一天。"
 },
 {
 "title": "感冒",
 "zs": "较易发",
 "tipt": "感冒指数",
 "des": "天气转凉，空气湿度较大，较易发生感冒，体质较弱的朋友请注意适当防护。"
 },
 {
 "title": "运动",
 "zs": "较适宜",
 "tipt": "运动指数",
 "des": "阴天，较适宜进行各种户内外运动。"
 },
 {
 "title": "紫外线强度",
 "zs": "最弱",
 "tipt": "紫外线强度指数",
 "des": "属弱紫外线辐射天气，无需特别防护。若长期在户外，建议涂擦SPF在8-12之间的防晒护肤品。"
 }
 ]
 
 */

@interface ActiveData : BaseModel

@property (nonatomic,copy) NSString *title;//活动主题
@property (nonatomic,copy) NSString *zs;//适宜程度
@property (nonatomic,copy) NSString *tipt;//活动指数
@property (nonatomic,copy) NSString *des;//活动建议

@end
