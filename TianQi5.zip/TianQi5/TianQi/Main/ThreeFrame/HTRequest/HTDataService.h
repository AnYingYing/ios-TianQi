//
//  WCDataService.h
//  03 DataService
//
//  Created by bing on 16/8/13.
//  Copyright © 2016年 bing. All rights reserved.
//

#import <Foundation/Foundation.h>

//自定义，未引入AFNetworking

// data
typedef  void (^CompletionBlock)(id data);

@interface HTDataService : NSObject

//get请求

//http://piao.163.com/m/cinema/list.html

//params: apiVer=6&city=110000
+(void)getWithURL:(NSString*)urlStr
            params:(NSMutableDictionary*)params
       headerField:(NSMutableDictionary*)headerFields
   comPletionBlock:(CompletionBlock)block;


//post请求
/*发送post请求
 *url:本地url的字符串
 *params:参数(字典) 简单的数据
 *headerField:请求头
 *formData:请求体(复杂的数据 imageData)
 *block:成功的block
 @return:nil
 
 */

+(void)postWithURL:(NSString*)urlStr
            params:(NSMutableDictionary*)params
       headerField:(NSMutableDictionary*)headerFields
          formData:(NSData*)formData
   comPletionBlock:(CompletionBlock)block;






@end
