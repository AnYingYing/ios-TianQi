//
//  LiveTableViewCell.h
//  TianQi
//
//  Created by LM on 17/3/31.
//  Copyright © 2017年 LM. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "LiveModel.h"

@interface LiveTableViewCell : UITableViewCell

@property (nonatomic,strong) LiveModel *model;

@end
