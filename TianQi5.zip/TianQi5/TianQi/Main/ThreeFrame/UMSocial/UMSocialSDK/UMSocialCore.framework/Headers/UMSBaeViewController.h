//
//  UMSBaeViewController.h
//  UMSocialSDK
//
//  Created by wyq.Cloudayc on 11/22/16.
//  Copyright © 2016 UMeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UMSBaeViewController : UIViewController

@property (nonatomic, strong) NSString *titleString;

- (CGFloat)viewOffsetY;

@end
