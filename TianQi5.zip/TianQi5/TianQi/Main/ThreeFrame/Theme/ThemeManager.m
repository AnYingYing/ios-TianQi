//
//  ThemeManager.m
//  TianQi
//
//  Created by LM on 17/3/23.
//  Copyright © 2017年 LM. All rights reserved.

#import "ThemeManager.h"

@implementation ThemeManager
+(id)shareManager;{
    
    static ThemeManager *instance = nil;
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
      
        instance = [[ThemeManager alloc] init];
    });
    
    return instance;
}

//设置初始化
- (instancetype)init{
    if ([super init]) {
        //设置默认主题
        
       NSString *themeName = [[NSUserDefaults standardUserDefaults] objectForKey:@"ThemeName"];
        _themeName = themeName ? :@"白天";
        
        [self loadConfig];
    }
    return self;
}
- (NSString *)loadThemePath{
//    .../Skins/cat/
   NSString *filePath = [[NSBundle mainBundle]pathForResource:@"Theme.plist" ofType:nil];
    NSDictionary *themeDic = [NSDictionary dictionaryWithContentsOfFile:filePath];
    //主题的名字
    //Skins/cat/
   NSString *themePath = [themeDic objectForKey:_themeName];

    //完整的
   NSString *path = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:themePath];
    return path;
}

-(UIImage *)getThemeImgWithImgName:(NSString *)imgName;{
    
    //图片路径
  NSString *imgPath = [[self loadThemePath] stringByAppendingPathComponent:imgName];
    
    UIImage *img = [UIImage imageWithContentsOfFile:imgPath];
    
    return img;
}

- (void)setThemeName:(NSString *)themeName{
    if (_themeName != themeName) {
        _themeName = themeName ;
        
        [self loadConfig];
        [[NSUserDefaults standardUserDefaults] setObject:_themeName forKey:@"ThemeName"];
        [[NSUserDefaults standardUserDefaults]synchronize];
        
        
        [[NSNotificationCenter defaultCenter] postNotificationName:@"ThemeChange" object:nil];
        
        
        
    }
    
}

//获取config.plist
- (void)loadConfig{
    
   NSString *themePath = [self loadThemePath];
    
    NSString *fliepath =[themePath stringByAppendingPathComponent:@"config.plist"];
   _colorDic = [NSDictionary dictionaryWithContentsOfFile:fliepath];
    
    //------------
    //先设置颜色
    if([_themeName isEqualToString:@"白天"]){
        
        self.themeColor = [UIColor blackColor];
    } else if([_themeName isEqualToString:@"黑夜"]) {
        
        self.themeColor = [UIColor whiteColor];
        
    }
    //------------
    
    
}
- (UIColor *)getThemeColorWithColorName:(NSString *)colorName;{
    
    NSDictionary *rgbDic = _colorDic[colorName];
    
    double R = [rgbDic[@"R"] doubleValue];
    double G = [rgbDic[@"G"] doubleValue];
    double B = [rgbDic[@"B"] doubleValue];
    double alpha = [rgbDic[@"alpha"] doubleValue]  ?  : 1;

    return [UIColor colorWithRed:R/255 green:G/255 blue:B/255 alpha:alpha];
}
@end
