//
//  ShowView.h
//  TianQi
//
//  Created by LM on 17/3/29.
//  Copyright © 2017年 LM. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ShowView : UIView

@property (nonatomic,strong) UIColor *bgColor;

@property (nonatomic,strong) NSMutableDictionary *dataDic;

@end
